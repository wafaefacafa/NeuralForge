// EXPORTS: CHART_COLORS, CHART_COLORS_HEX, CHART_COLOR_MAP

/**
 * NeuralForge 图表颜色常量
 * 深色主题 ECharts 配色方案
 * 主色调：靛蓝 #4F46E5 + 青色 #06B6D4
 */

/** 图表系列色板（hex 值，供 ECharts option.color 直接使用） */
export const CHART_COLORS = [
  '#4F46E5', // chart-1: 靛蓝 primary
  '#06B6D4', // chart-2: 青色 accent
  '#A855F7', // chart-3: 紫色
  '#22C55E', // chart-4: 绿色
  '#818CF8', // chart-5: 浅靛蓝
] as const;

/** 图表颜色 hex 值映射（按语义 key 访问） */
export const CHART_COLORS_HEX = {
  primary: '#4F46E5',
  accent: '#06B6D4',
  purple: '#A855F7',
  green: '#22C55E',
  lightIndigo: '#818CF8',
  red: '#EF4444',
  orange: '#F59E0B',
  yellow: '#EAB308',
  teal: '#14B8A6',
  pink: '#EC4899',
  gray: '#6B7280',
  darkGray: '#374151',
} as const;

/** 语义化颜色映射（供图表中按状态/类型着色） */
export const CHART_COLOR_MAP = {
  success: '#22C55E',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#4F46E5',
  running: '#22C55E',
  stopped: '#6B7280',
  failed: '#EF4444',
  pending: '#F59E0B',
  deployed: '#06B6D4',
  training: '#A855F7',
  queued: '#818CF8',
  cpu: '#4F46E5',
  gpu: '#06B6D4',
  memory: '#A855F7',
  storage: '#22C55E',
  network: '#F59E0B',
} as const;
