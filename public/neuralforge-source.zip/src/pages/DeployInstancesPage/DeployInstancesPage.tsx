import { useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import {
  Server,
  Search,
  RefreshCw,
  Play,
  Square,
  Maximize2,
  RotateCcw,
  Trash2,
  ExternalLink,
  Copy,
  Filter,
  ChevronDown,
  Activity,
  Clock,
  Zap,
  Cpu,
  HardDrive,
  Terminal,
  X,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Loader2,
  Pause,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';

import { MOCK_DEPLOY_INSTANCES } from '@/data/deployInstances';
import type { IDeployInstance } from '@/types/deploy';

// ---------- 状态映射 ----------
const STATUS_CONFIG: Record<
  IDeployInstance['status'],
  { label: string; icon: React.ComponentType<{ className?: string }>; color: string; bg: string }
> = {
  running: {
    label: '运行中',
    icon: CheckCircle2,
    color: 'text-success',
    bg: 'bg-success/10',
  },
  stopped: {
    label: '已停止',
    icon: Pause,
    color: 'text-muted-foreground',
    bg: 'bg-muted',
  },
  deploying: {
    label: '部署中',
    icon: Loader2,
    color: 'text-warning',
    bg: 'bg-warning/10',
  },
  failed: {
    label: '异常',
    icon: XCircle,
    color: 'text-destructive',
    bg: 'bg-destructive/10',
  },
  scaling: {
    label: '扩缩容中',
    icon: Activity,
    color: 'text-accent',
    bg: 'bg-accent/10',
  },
};

// ---------- 模拟日志 ----------
function generateMockLogs(instanceId: string): { timestamp: string; level: 'info' | 'warn' | 'error'; message: string }[] {
  const base = new Date();
  const logs: { timestamp: string; level: 'info' | 'warn' | 'error'; message: string }[] = [];
  const messages = [
    { level: 'info' as const, msg: `[${instanceId}] 健康检查通过 - 状态码 200` },
    { level: 'info' as const, msg: `[${instanceId}] 推理请求处理完成 - 耗时 45ms` },
    { level: 'info' as const, msg: `[${instanceId}] 模型版本 v2.3.1 已加载` },
    { level: 'warn' as const, msg: `[${instanceId}] GPU 显存使用率 78%，接近阈值` },
    { level: 'info' as const, msg: `[${instanceId}] 批量推理请求 (batch_size=32) 完成` },
    { level: 'info' as const, msg: `[${instanceId}] 自动扩缩容检查 - 当前实例数 3，无需调整` },
    { level: 'error' as const, msg: `[${instanceId}] 请求超时 - endpoint /v1/predict, timeout 30s` },
    { level: 'info' as const, msg: `[${instanceId}] 连接池状态 - active=12, idle=8` },
    { level: 'warn' as const, msg: `[${instanceId}] 内存使用率 82%，建议关注` },
    { level: 'info' as const, msg: `[${instanceId}] 日志轮转完成 - 归档 150MB` },
    { level: 'info' as const, msg: `[${instanceId}] 新版本模型预热完成 - 缓存命中率 94%` },
    { level: 'info' as const, msg: `[${instanceId}] gRPC 流式响应通道已建立` },
  ];

  messages.forEach((m, i) => {
    const ts = new Date(base.getTime() - (messages.length - i) * 30000);
    logs.push({
      timestamp: ts.toISOString().slice(11, 19),
      level: m.level,
      message: m.msg,
    });
  });

  return logs;
}

// ---------- 迷你折线图（纯 CSS/SVG） ----------
function MiniSparkline({ data }: { data: number[] }) {
  if (data.length < 2) return null;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const range = max - min || 1;
  const w = 80;
  const h = 24;
  const points = data
    .map((v, i) => {
      const x = (i / (data.length - 1)) * w;
      const y = h - ((v - min) / range) * (h - 4) - 2;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <svg width={w} height={h} className="shrink-0" aria-label="请求趋势">
      <polyline
        points={points}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-primary"
      />
    </svg>
  );
}

// ---------- Page ----------
export default function DeployInstancesPage() {
  const navigate = useNavigate();

  // 实例数据
  const [instances, setInstances] = useState<IDeployInstance[]>(MOCK_DEPLOY_INSTANCES);

  // 搜索 & 筛选
  const [searchKeyword, setSearchKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [envFilter, setEnvFilter] = useState('all');

  // 日志抽屉
  const [logInstance, setLogInstance] = useState<IDeployInstance | null>(null);
  const [logs, setLogs] = useState<ReturnType<typeof generateMockLogs>>([]);
  const [logAutoScroll, setLogAutoScroll] = useState(true);

  // 操作确认
  const [actionTarget, setActionTarget] = useState<{
    instance: IDeployInstance;
    action: 'start' | 'stop' | 'delete' | 'rollback';
  } | null>(null);

  // 刷新动画
  const [refreshing, setRefreshing] = useState(false);

  // ---------- 筛选后的实例列表 ----------
  const filteredInstances = useMemo(() => {
    return instances.filter((inst) => {
      const matchSearch =
        !searchKeyword.trim() ||
        inst.name.toLowerCase().includes(searchKeyword.toLowerCase()) ||
        inst.modelName.toLowerCase().includes(searchKeyword.toLowerCase()) ||
        inst.endpoint.toLowerCase().includes(searchKeyword.toLowerCase());

      const matchStatus = statusFilter === 'all' || inst.status === statusFilter;
      const matchEnv = envFilter === 'all' || inst.environment === envFilter;

      return matchSearch && matchStatus && matchEnv;
    });
  }, [instances, searchKeyword, statusFilter, envFilter]);

  // ---------- 统计 ----------
  const stats = useMemo(() => {
    const total = instances.length;
    const running = instances.filter((i) => i.status === 'running').length;
    const failed = instances.filter((i) => i.status === 'failed').length;
    const stopped = instances.filter((i) => i.status === 'stopped').length;
    return { total, running, failed, stopped };
  }, [instances]);

  // ---------- 刷新 ----------
  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await new Promise((r) => setTimeout(r, 800));
      // 模拟数据微调
      setInstances((prev) =>
        prev.map((inst) => ({
          ...inst,
          qps: inst.qps + Math.floor(Math.random() * 20 - 10),
          cpuUsage: Math.min(100, Math.max(5, inst.cpuUsage + Math.floor(Math.random() * 6 - 3))),
          memoryUsage: Math.min(100, Math.max(10, inst.memoryUsage + Math.floor(Math.random() * 6 - 3))),
          requestHistory: [
            ...inst.requestHistory.slice(1),
            inst.qps + Math.floor(Math.random() * 30 - 15),
          ],
        })),
      );
      toast.success('数据已刷新');
    } catch {
      toast.error('刷新失败');
    } finally {
      setRefreshing(false);
    }
  }, []);

  // ---------- 操作处理 ----------
  const handleStart = useCallback((instance: IDeployInstance) => {
    setInstances((prev) =>
      prev.map((i) => (i.id === instance.id ? { ...i, status: 'deploying' as const } : i)),
    );
    toast.success(`实例 ${instance.name} 正在启动...`);
    logger.info('Instance start:', instance.id);
    // 模拟启动完成
    setTimeout(() => {
      setInstances((prev) =>
        prev.map((i) =>
          i.id === instance.id
            ? { ...i, status: 'running' as const, uptime: '0 分钟' }
            : i,
        ),
      );
      toast.success(`实例 ${instance.name} 已启动`);
    }, 2000);
  }, []);

  const handleStop = useCallback((instance: IDeployInstance) => {
    setInstances((prev) =>
      prev.map((i) => (i.id === instance.id ? { ...i, status: 'stopped' as const } : i)),
    );
    toast.success(`实例 ${instance.name} 已停止`);
    logger.info('Instance stopped:', instance.id);
  }, []);

  const handleDelete = useCallback((instance: IDeployInstance) => {
    setInstances((prev) => prev.filter((i) => i.id !== instance.id));
    toast.success(`实例 ${instance.name} 已删除`);
    logger.info('Instance deleted:', instance.id);
  }, []);

  const handleRollback = useCallback((instance: IDeployInstance) => {
    toast.success(`实例 ${instance.name} 正在回滚至上一版本...`);
    logger.info('Instance rollback:', instance.id);
    setTimeout(() => {
      toast.success(`实例 ${instance.name} 回滚完成`);
    }, 1500);
  }, []);

  const confirmAction = useCallback(() => {
    if (!actionTarget) return;
    const { instance, action } = actionTarget;
    switch (action) {
      case 'start':
        handleStart(instance);
        break;
      case 'stop':
        handleStop(instance);
        break;
      case 'delete':
        handleDelete(instance);
        break;
      case 'rollback':
        handleRollback(instance);
        break;
    }
    setActionTarget(null);
  }, [actionTarget, handleStart, handleStop, handleDelete, handleRollback]);

  // ---------- 日志 ----------
  const handleOpenLogs = useCallback((instance: IDeployInstance) => {
    setLogInstance(instance);
    setLogs(generateMockLogs(instance.id));
    setLogAutoScroll(true);
  }, []);

  const handleCloseLogs = useCallback(() => {
    setLogInstance(null);
    setLogs([]);
  }, []);

  // 模拟日志追加
  const handleRefreshLogs = useCallback(() => {
    if (!logInstance) return;
    const newLog = {
      timestamp: new Date().toISOString().slice(11, 19),
      level: (['info', 'info', 'info', 'warn'] as const)[Math.floor(Math.random() * 4)],
      message: `[${logInstance.id}] 健康检查通过 - QPS ${logInstance.qps + Math.floor(Math.random() * 10)}`,
    };
    setLogs((prev) => [...prev, newLog]);
    toast.success('日志已刷新');
  }, [logInstance]);

  // ---------- 复制端点 ----------
  const handleCopyEndpoint = useCallback(async (endpoint: string) => {
    try {
      await navigator.clipboard.writeText(endpoint);
      toast.success('端点已复制到剪贴板');
    } catch {
      toast.error('复制失败');
    }
  }, []);

  // ---------- 环境筛选选项 ----------
  const envOptions = useMemo(() => {
    const envs = [...new Set(instances.map((i) => i.environment))];
    return envs;
  }, [instances]);

  return (
    <div className="space-y-6">
      {/* ========== 顶部统计卡片 ========== */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {
            label: '实例总数',
            value: stats.total,
            icon: Server,
            color: 'text-primary',
            bg: 'bg-primary/10',
          },
          {
            label: '运行中',
            value: stats.running,
            icon: CheckCircle2,
            color: 'text-success',
            bg: 'bg-success/10',
          },
          {
            label: '异常',
            value: stats.failed,
            icon: AlertTriangle,
            color: 'text-destructive',
            bg: 'bg-destructive/10',
          },
          {
            label: '已停止',
            value: stats.stopped,
            icon: Pause,
            color: 'text-muted-foreground',
            bg: 'bg-muted',
          },
        ].map((card, i) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={card.label}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
            >
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                        {card.label}
                      </p>
                      <p className="text-2xl font-bold tabular-nums tracking-tight text-foreground">
                        {card.value}
                      </p>
                    </div>
                    <div className={`flex size-9 items-center justify-center rounded-lg ${card.bg}`}>
                      <Icon className={`size-4.5 ${card.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* ========== 搜索 & 筛选栏 ========== */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            {/* 左侧：搜索 + 筛选 */}
            <div className="flex flex-1 flex-wrap items-center gap-3">
              {/* 搜索框 */}
              <div className="relative w-full sm:max-w-xs">
                <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  placeholder="搜索实例名称、模型..."
                  className="bg-muted/50 pl-9 text-sm"
                />
              </div>

              {/* 状态筛选 */}
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[130px] bg-muted/50 text-sm">
                  <Filter className="mr-1.5 size-3.5 text-muted-foreground" />
                  <SelectValue placeholder="状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="running">运行中</SelectItem>
                  <SelectItem value="stopped">已停止</SelectItem>
                  <SelectItem value="deploying">部署中</SelectItem>
                  <SelectItem value="failed">异常</SelectItem>
                  <SelectItem value="scaling">扩缩容中</SelectItem>
                </SelectContent>
              </Select>

              {/* 环境筛选 */}
              <Select value={envFilter} onValueChange={setEnvFilter}>
                <SelectTrigger className="w-[130px] bg-muted/50 text-sm">
                  <Server className="mr-1.5 size-3.5 text-muted-foreground" />
                  <SelectValue placeholder="环境" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部环境</SelectItem>
                  {envOptions.map((env) => (
                    <SelectItem key={env} value={env}>
                      {env === 'production' ? '生产环境' : env === 'staging' ? '预发布' : '测试'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* 右侧：刷新按钮 */}
            <div className="flex items-center gap-2">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="icon"
                      className="size-9"
                      onClick={handleRefresh}
                      disabled={refreshing}
                      aria-label="刷新数据"
                    >
                      <RefreshCw className={`size-4 ${refreshing ? 'animate-spin' : ''}`} />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">刷新数据</TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ========== 实例列表表格 ========== */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Server className="size-5 text-primary" />
            部署实例
            <Badge variant="secondary" className="ml-1 text-xs">
              {filteredInstances.length}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {filteredInstances.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <Server className="size-14 text-muted-foreground/30 mb-4" />
              <p className="text-sm font-medium text-muted-foreground">没有找到匹配的实例</p>
              <p className="text-xs text-muted-foreground/60 mt-1">
                尝试调整搜索关键词或筛选条件
              </p>
            </div>
          ) : (
            <div className="w-full overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap">实例名称</TableHead>
                    <TableHead className="whitespace-nowrap">模型版本</TableHead>
                    <TableHead className="whitespace-nowrap">状态</TableHead>
                    <TableHead className="whitespace-nowrap">端点</TableHead>
                    <TableHead className="whitespace-nowrap">规格</TableHead>
                    <TableHead className="whitespace-nowrap">运行时长</TableHead>
                    <TableHead className="whitespace-nowrap">QPS</TableHead>
                    <TableHead className="whitespace-nowrap">资源使用</TableHead>
                    <TableHead className="whitespace-nowrap">请求趋势</TableHead>
                    <TableHead className="whitespace-nowrap text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredInstances.map((inst, idx) => {
                    const statusCfg = STATUS_CONFIG[inst.status];
                    const StatusIcon = statusCfg.icon;

                    return (
                      <motion.tr
                        key={inst.id}
                        initial={{ opacity: 0, y: 8 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.35, delay: idx * 0.03 }}
                        className="border-b border-border/30"
                      >
                        {/* 实例名称 */}
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2 min-w-0">
                            <div className={`flex size-7 shrink-0 items-center justify-center rounded-md ${statusCfg.bg}`}>
                              <StatusIcon className={`size-3.5 ${statusCfg.color} ${inst.status === 'deploying' ? 'animate-spin' : ''}`} />
                            </div>
                            <div className="min-w-0">
                              <span className="block truncate max-w-[140px] text-sm font-semibold">
                                {inst.name}
                              </span>
                              <span className="text-[11px] text-muted-foreground">
                                {inst.modelName}
                              </span>
                            </div>
                          </div>
                        </TableCell>

                        {/* 模型版本 */}
                        <TableCell>
                          <Badge variant="outline" className="text-xs font-mono">
                            {inst.modelVersionName}
                          </Badge>
                        </TableCell>

                        {/* 状态 */}
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={`text-xs gap-1 ${statusCfg.color} border-current/30 ${statusCfg.bg}`}
                          >
                            <StatusIcon className={`size-3 ${inst.status === 'deploying' ? 'animate-spin' : ''}`} />
                            {statusCfg.label}
                          </Badge>
                        </TableCell>

                        {/* 端点 */}
                        <TableCell>
                          <div className="flex items-center gap-1.5 min-w-0">
                            <code className="block truncate max-w-[160px] rounded bg-muted/50 px-1.5 py-0.5 text-[11px] font-mono text-muted-foreground">
                              {inst.endpoint}
                            </code>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="size-6 shrink-0"
                                    onClick={() => handleCopyEndpoint(inst.endpoint)}
                                    aria-label="复制端点"
                                  >
                                    <Copy className="size-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent side="top">复制端点</TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="size-6 shrink-0"
                                    onClick={() => window.open(`https://${inst.endpoint}`, '_blank')}
                                    aria-label="打开端点"
                                  >
                                    <ExternalLink className="size-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent side="top">打开端点</TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                        </TableCell>

                        {/* 规格 */}
                        <TableCell>
                          <span className="text-xs text-muted-foreground whitespace-nowrap">
                            {inst.spec}
                          </span>
                        </TableCell>

                        {/* 运行时长 */}
                        <TableCell>
                          <div className="flex items-center gap-1.5 whitespace-nowrap text-xs text-muted-foreground">
                            <Clock className="size-3" />
                            {inst.uptime}
                          </div>
                        </TableCell>

                        {/* QPS */}
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            <Zap className="size-3 text-accent" />
                            <span className="text-sm font-semibold tabular-nums text-foreground">
                              {inst.qps}
                            </span>
                          </div>
                        </TableCell>

                        {/* 资源使用 */}
                        <TableCell>
                          <div className="space-y-1.5 min-w-[100px]">
                            {/* CPU */}
                            <div className="flex items-center gap-2">
                              <Cpu className="size-3 text-muted-foreground shrink-0" />
                              <Progress
                                value={inst.cpuUsage}
                                className={`h-1.5 flex-1 ${inst.cpuUsage > 80 ? '[&>div]:bg-destructive' : inst.cpuUsage > 60 ? '[&>div]:bg-warning' : '[&>div]:bg-primary'}`}
                              />
                              <span className="text-[10px] tabular-nums text-muted-foreground w-8 text-right">
                                {inst.cpuUsage}%
                              </span>
                            </div>
                            {/* 内存 */}
                            <div className="flex items-center gap-2">
                              <HardDrive className="size-3 text-muted-foreground shrink-0" />
                              <Progress
                                value={inst.memoryUsage}
                                className={`h-1.5 flex-1 ${inst.memoryUsage > 80 ? '[&>div]:bg-destructive' : inst.memoryUsage > 60 ? '[&>div]:bg-warning' : '[&>div]:bg-accent'}`}
                              />
                              <span className="text-[10px] tabular-nums text-muted-foreground w-8 text-right">
                                {inst.memoryUsage}%
                              </span>
                            </div>
                          </div>
                        </TableCell>

                        {/* 请求趋势 */}
                        <TableCell>
                          <MiniSparkline data={inst.requestHistory} />
                        </TableCell>

                        {/* 操作 */}
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 gap-1 text-xs">
                                操作
                                <ChevronDown className="size-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-40">
                              {inst.status === 'stopped' || inst.status === 'failed' ? (
                                <DropdownMenuItem
                                  className="cursor-pointer"
                                  onClick={() => setActionTarget({ instance: inst, action: 'start' })}
                                >
                                  <Play className="mr-2 size-3.5 text-success" />
                                  启动
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem
                                  className="cursor-pointer"
                                  onClick={() => setActionTarget({ instance: inst, action: 'stop' })}
                                >
                                  <Square className="mr-2 size-3.5 text-warning" />
                                  停止
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                className="cursor-pointer"
                                onClick={() => toast.info('扩容功能')}
                              >
                                <Maximize2 className="mr-2 size-3.5" />
                                扩容
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="cursor-pointer"
                                onClick={() => handleOpenLogs(inst)}
                              >
                                <Terminal className="mr-2 size-3.5" />
                                查看日志
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="cursor-pointer"
                                onClick={() => setActionTarget({ instance: inst, action: 'rollback' })}
                              >
                                <RotateCcw className="mr-2 size-3.5" />
                                版本回滚
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="cursor-pointer text-destructive focus:text-destructive"
                                onClick={() => setActionTarget({ instance: inst, action: 'delete' })}
                              >
                                <Trash2 className="mr-2 size-3.5" />
                                删除
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </motion.tr>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ========== 操作确认对话框 ========== */}
      <AlertDialog
        open={!!actionTarget}
        onOpenChange={(open) => {
          if (!open) setActionTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              {actionTarget?.action === 'start' && <Play className="size-5 text-success" />}
              {actionTarget?.action === 'stop' && <Square className="size-5 text-warning" />}
              {actionTarget?.action === 'delete' && <Trash2 className="size-5 text-destructive" />}
              {actionTarget?.action === 'rollback' && <RotateCcw className="size-5 text-accent" />}
              {actionTarget?.action === 'start' && '启动实例'}
              {actionTarget?.action === 'stop' && '停止实例'}
              {actionTarget?.action === 'delete' && '删除实例'}
              {actionTarget?.action === 'rollback' && '版本回滚'}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {actionTarget?.action === 'start' &&
                `确定要启动实例「${actionTarget?.instance.name}」吗？启动后实例将开始接收推理请求。`}
              {actionTarget?.action === 'stop' &&
                `确定要停止实例「${actionTarget?.instance.name}」吗？停止后该实例将不再处理请求，可能影响在线服务。`}
              {actionTarget?.action === 'delete' &&
                `确定要删除实例「${actionTarget?.instance.name}」吗？此操作不可撤销，所有相关配置和日志将被永久删除。`}
              {actionTarget?.action === 'rollback' &&
                `确定要将实例「${actionTarget?.instance.name}」回滚至上一版本吗？回滚期间服务可能短暂中断。`}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmAction}
              className={
                actionTarget?.action === 'delete'
                  ? 'bg-destructive text-destructive-foreground hover:bg-destructive/90'
                  : ''
              }
            >
              {actionTarget?.action === 'start' && '确认启动'}
              {actionTarget?.action === 'stop' && '确认停止'}
              {actionTarget?.action === 'delete' && '确认删除'}
              {actionTarget?.action === 'rollback' && '确认回滚'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ========== 日志抽屉 ========== */}
      <Sheet open={!!logInstance} onOpenChange={(open) => { if (!open) handleCloseLogs(); }}>
        <SheetContent side="right" className="w-full sm:max-w-[560px] flex flex-col p-0">
          {/* 日志头部 */}
          <SheetHeader className="px-5 py-4 border-b border-border/40 shrink-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <Terminal className="size-4.5 text-primary" />
                </div>
                <div className="min-w-0">
                  <SheetTitle className="text-base truncate">
                    {logInstance?.name}
                  </SheetTitle>
                  <SheetDescription className="text-xs truncate">
                    {logInstance?.modelName} · {logInstance?.modelVersionName}
                  </SheetDescription>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8"
                        onClick={handleRefreshLogs}
                        aria-label="刷新日志"
                      >
                        <RefreshCw className="size-3.5" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="bottom">刷新日志</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8"
                  onClick={handleCloseLogs}
                  aria-label="关闭"
                >
                  <X className="size-4" />
                </Button>
              </div>
            </div>

            {/* 实例状态摘要 */}
            {logInstance && (
              <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <Activity className="size-3" />
                  <span>QPS: <span className="font-semibold text-foreground tabular-nums">{logInstance.qps}</span></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Cpu className="size-3" />
                  <span>CPU: <span className="font-semibold text-foreground tabular-nums">{logInstance.cpuUsage}%</span></span>
                </div>
                <div className="flex items-center gap-1.5">
                  <HardDrive className="size-3" />
                  <span>内存: <span className="font-semibold text-foreground tabular-nums">{logInstance.memoryUsage}%</span></span>
                </div>
              </div>
            )}
          </SheetHeader>

          {/* 日志内容区域 */}
          <div className="flex-1 overflow-y-auto bg-[#0a0d14] font-mono text-xs">
            {logs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                <Terminal className="size-10 mb-3 opacity-30" />
                <p>暂无日志</p>
              </div>
            ) : (
              <div className="py-3">
                {logs.map((log, i) => (
                  <div
                    key={i}
                    className={`flex gap-3 px-4 py-1 hover:bg-white/[0.03] transition-colors ${
                      log.level === 'error'
                        ? 'bg-destructive/5 text-destructive/90'
                        : log.level === 'warn'
                          ? 'bg-warning/5 text-warning/90'
                          : 'text-muted-foreground'
                    }`}
                  >
                    <span className="shrink-0 text-[10px] text-muted-foreground/60 w-14 tabular-nums">
                      {log.timestamp}
                    </span>
                    <span
                      className={`shrink-0 w-8 text-[10px] uppercase font-semibold ${
                        log.level === 'error'
                          ? 'text-destructive'
                          : log.level === 'warn'
                            ? 'text-warning'
                            : 'text-accent'
                      }`}
                    >
                      {log.level}
                    </span>
                    <span className="break-all">{log.message}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 日志底部操作栏 */}
          <div className="flex items-center justify-between px-4 py-2.5 border-t border-border/40 bg-card/80 shrink-0">
            <div className="flex items-center gap-1.5">
              <Badge variant="outline" className="text-[10px] h-5 px-1.5">
                {logs.length} 条
              </Badge>
              <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={logAutoScroll}
                  onChange={(e) => setLogAutoScroll(e.target.checked)}
                  className="size-3 rounded border-border accent-primary"
                />
                自动滚动
              </label>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs"
              onClick={handleRefreshLogs}
            >
              <RefreshCw className="mr-1 size-3" />
              刷新
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
