import { useState, useCallback, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import { Download, RefreshCw, Clock, Filter } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import ResourceUsageCharts from './ResourceUsageCharts';
import ResourceQuotaCards from './ResourceQuotaCards';
import CostBreakdownChart from './CostBreakdownChart';
import ResourceAlertTable from './ResourceAlertTable';

import { MOCK_RESOURCE_METRICS, MOCK_RESOURCE_QUOTAS, MOCK_COST_BREAKDOWN } from '@/data/resourceMetrics';
import { MOCK_RESOURCE_ALERTS } from '@/data/resourceAlerts';
import type { IResourceTimeSeries, IResourceAlert } from '@/types/resources';

const TIME_RANGE_OPTIONS = [
  { value: '1h', label: '最近 1 小时' },
  { value: '6h', label: '最近 6 小时' },
  { value: '24h', label: '最近 24 小时' },
  { value: '7d', label: '最近 7 天' },
] as const;

type TimeRange = (typeof TIME_RANGE_OPTIONS)[number]['value'];

// 按时间范围截取数据
function sliceByTimeRange(data: IResourceTimeSeries[], range: TimeRange): IResourceTimeSeries[] {
  const countMap: Record<TimeRange, number> = { '1h': 12, '6h': 24, '24h': 48, '7d': 56 };
  const count = countMap[range];
  if (data.length <= count) return data;
  return data.slice(data.length - count);
}

export default function ResourceMonitorPage() {
  const [timeRange, setTimeRange] = useState<TimeRange>('24h');
  const [alerts, setAlerts] = useState<IResourceAlert[]>(MOCK_RESOURCE_ALERTS);
  const [refreshing, setRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());

  // 按时间范围过滤指标数据
  const filteredMetrics = useMemo(
    () => ({
      cpu: sliceByTimeRange(MOCK_RESOURCE_METRICS.cpu, timeRange),
      gpu: sliceByTimeRange(MOCK_RESOURCE_METRICS.gpu, timeRange),
      memory: sliceByTimeRange(MOCK_RESOURCE_METRICS.memory, timeRange),
      storage: sliceByTimeRange(MOCK_RESOURCE_METRICS.storage, timeRange),
    }),
    [timeRange],
  );

  // 模拟实时刷新
  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await new Promise((r) => setTimeout(r, 800));
      setLastRefresh(new Date());
      toast.success('数据已刷新');
      logger.info('Resource metrics refreshed');
    } catch (err) {
      logger.error('Refresh failed:', String(err));
      toast.error('刷新失败');
    } finally {
      setRefreshing(false);
    }
  }, []);

  // 模拟导出报告
  const handleExport = useCallback(async () => {
    try {
      await new Promise((r) => setTimeout(r, 600));
      toast.success('报告已导出为 CSV');
      logger.info('Resource report exported');
    } catch (err) {
      logger.error('Export failed:', String(err));
      toast.error('导出失败');
    }
  }, []);

  // 处理告警操作
  const handleAcknowledgeAlert = useCallback((alertId: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, status: 'acknowledged' as const } : a)),
    );
    toast.success('告警已确认');
  }, []);

  const handleResolveAlert = useCallback((alertId: string) => {
    setAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, status: 'resolved' as const } : a)),
    );
    toast.success('告警已解决');
  }, []);

  // 定时自动刷新（每 30 秒）
  useEffect(() => {
    const timer = setInterval(() => {
      setLastRefresh(new Date());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const activeAlertCount = alerts.filter((a) => a.status === 'active').length;

  return (
    <div className="space-y-6">
      {/* 页面标题栏 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h1 className="text-xl font-bold tracking-tight text-foreground">资源监控</h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            实时监控 CPU / GPU / 内存 / 存储使用情况
            {activeAlertCount > 0 && (
              <span className="ml-2 inline-flex items-center gap-1 rounded-full bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
                {activeAlertCount} 条活跃告警
              </span>
            )}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* 最后刷新时间 */}
          <span className="hidden text-xs text-muted-foreground sm:flex items-center gap-1">
            <Clock className="size-3" />
            {lastRefresh.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </span>

          {/* 时间范围选择 */}
          <Select value={timeRange} onValueChange={(v) => setTimeRange(v as TimeRange)}>
            <SelectTrigger className="h-9 w-[130px] bg-muted/50 text-xs">
              <Filter className="mr-1.5 size-3.5" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {TIME_RANGE_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* 刷新按钮 */}
          <Button
            variant="outline"
            size="sm"
            className="h-9 gap-1.5"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <RefreshCw className={`size-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            {refreshing ? '刷新中' : '刷新'}
          </Button>

          {/* 导出按钮 */}
          <Button variant="outline" size="sm" className="h-9 gap-1.5" onClick={handleExport}>
            <Download className="size-3.5" />
            <span className="hidden sm:inline">导出报告</span>
          </Button>
        </div>
      </motion.div>

      {/* 资源配额概览卡片 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.05 }}
      >
        <ResourceQuotaCards quotas={MOCK_RESOURCE_QUOTAS} />
      </motion.div>

      {/* 实时资源使用率图表（4 个折线图） */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.1 }}
      >
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">实时资源使用率</CardTitle>
          </CardHeader>
          <CardContent>
            <ResourceUsageCharts metrics={filteredMetrics} />
          </CardContent>
        </Card>
      </motion.div>

      {/* 费用统计 + 告警列表（双列布局） */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* 费用统计环形图（左 1/3） */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.15 }}
        >
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">本月费用构成</CardTitle>
            </CardHeader>
            <CardContent>
              <CostBreakdownChart data={MOCK_COST_BREAKDOWN} />
            </CardContent>
          </Card>
        </motion.div>

        {/* 资源告警列表（右 2/3） */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.2 }}
          className="lg:col-span-2"
        >
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">
                资源告警
                {activeAlertCount > 0 && (
                  <span className="ml-2 text-sm font-normal text-muted-foreground">
                    ({activeAlertCount} 条未处理)
                  </span>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ResourceAlertTable
                alerts={alerts}
                onAcknowledge={handleAcknowledgeAlert}
                onResolve={handleResolveAlert}
              />
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
