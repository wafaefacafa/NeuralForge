import ReactECharts from 'echarts-for-react';
import type { EChartsOption, CallbackDataParams } from 'echarts';
import { CHART_COLORS } from '@/lib/chart-colors';
import type { IPrPoint } from '@/types/models';

interface PrCurveChartProps {
  data: IPrPoint[];
  aucRoc: number;
}

export default function PrCurveChart({ data, aucRoc }: PrCurveChartProps) {
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(20, 24, 36, 0.95)',
      borderColor: '#374151',
      textStyle: { color: '#e5e7eb', fontSize: 12 },
      formatter: (params: CallbackDataParams) => {
        const p = params as { name: string; value: number[] };
        return `Recall: ${Number(p.value[0]).toFixed(3)}<br/>Precision: ${Number(p.value[1]).toFixed(3)}`;
      },
    },
    legend: {
      bottom: 0,
      textStyle: { color: '#9ca3af', fontSize: 12 },
      itemWidth: 12,
      itemHeight: 8,
      itemGap: 20,
      data: ['PR Curve', 'Baseline'],
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '20%',
      top: '8%',
      containLabel: true,
    },
    xAxis: {
      type: 'value',
      name: 'Recall',
      nameTextStyle: { color: '#9ca3af', fontSize: 11 },
      min: 0,
      max: 1,
      axisLine: { lineStyle: { color: '#374151' } },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: '#1f2937', type: 'dashed' } },
      axisLabel: {
        color: '#9ca3af',
        fontSize: 11,
        formatter: (value: number) => value.toFixed(1),
      },
    },
    yAxis: {
      type: 'value',
      name: 'Precision',
      nameTextStyle: { color: '#9ca3af', fontSize: 11 },
      min: 0,
      max: 1,
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: '#1f2937', type: 'dashed' } },
      axisLabel: {
        color: '#9ca3af',
        fontSize: 11,
        formatter: (value: number) => value.toFixed(1),
      },
    },
    series: [
      {
        name: 'PR Curve',
        type: 'line',
        data: data.map((p) => [p.recall, p.precision]),
        smooth: true,
        symbol: 'none',
        lineStyle: { width: 2.5, color: CHART_COLORS[0] },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(79, 70, 229, 0.2)' },
              { offset: 1, color: 'rgba(79, 70, 229, 0.02)' },
            ],
          },
        },
        markLine: {
          silent: true,
          symbol: 'none',
          lineStyle: { color: '#6b7280', type: 'dashed', width: 1 },
          label: {
            color: '#9ca3af',
            fontSize: 10,
            formatter: `AUC: ${aucRoc.toFixed(3)}`,
            position: 'insideEndTop',
          },
          data: [
            {
              xAxis: aucRoc,
              label: { formatter: `AUC: ${aucRoc.toFixed(3)}` },
            },
          ],
        },
      },
      {
        name: 'Baseline',
        type: 'line',
        data: [
          [0, 0.5],
          [1, 0.5],
        ],
        symbol: 'none',
        lineStyle: { color: '#6b7280', type: 'dashed', width: 1.5 },
        itemStyle: { color: '#6b7280' },
      },
    ],
  };

  return (
    <ReactECharts
      option={option}
      theme="ud"
      className="h-[350px] w-full"
      notMerge
      lazyUpdate
    />
  );
}
