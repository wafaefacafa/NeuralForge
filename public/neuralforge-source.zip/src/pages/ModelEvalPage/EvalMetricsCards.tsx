import { memo } from 'react';
import { motion } from 'framer-motion';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { Card, CardContent } from '@/components/ui/card';
import { CHART_COLORS } from '@/lib/chart-colors';

interface EvalMetricsCardsProps {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
}

const METRICS = [
  { key: 'accuracy', label: 'Accuracy', color: CHART_COLORS[0] },
  { key: 'precision', label: 'Precision', color: CHART_COLORS[1] },
  { key: 'recall', label: 'Recall', color: CHART_COLORS[2] },
  { key: 'f1Score', label: 'F1 Score', color: CHART_COLORS[3] },
] as const;

function buildGaugeOption(value: number, color: string): EChartsOption {
  return {
    series: [
      {
        type: 'gauge',
        startAngle: 210,
        endAngle: -30,
        center: ['50%', '55%'],
        radius: '85%',
        min: 0,
        max: 1,
        splitNumber: 10,
        axisLine: {
          show: true,
          lineStyle: {
            width: 12,
            color: [
              [value, color],
              [1, '#1f2937'],
            ],
          },
        },
        pointer: { show: false },
        axisTick: { show: false },
        splitLine: { show: false },
        axisLabel: { show: false },
        detail: {
          valueAnimation: true,
          formatter: (v: number) => `${(v * 100).toFixed(1)}%`,
          color: '#e5e7eb',
          fontSize: 16,
          fontWeight: 'bold',
          offsetCenter: [0, '60%'],
        },
        data: [{ value }],
      },
    ],
  };
}

function EvalMetricsCards({ accuracy, precision, recall, f1Score }: EvalMetricsCardsProps) {
  const values: Record<string, number> = { accuracy, precision, recall, f1Score };

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {METRICS.map((metric, i) => (
        <motion.div
          key={metric.key}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
        >
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm hover:border-primary/30 transition-colors duration-300">
            <CardContent className="p-4 flex flex-col items-center">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">
                {metric.label}
              </span>
              <div className="w-full h-[120px]">
                <ReactECharts
                  option={buildGaugeOption(values[metric.key], metric.color)}
                  theme="ud"
                  style={{ height: '100%', width: '100%' }}
                  notMerge
                  lazyUpdate
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

export default memo(EvalMetricsCards);
