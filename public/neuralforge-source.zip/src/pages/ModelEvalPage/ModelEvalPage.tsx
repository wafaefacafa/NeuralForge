import { useState, useMemo, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { ArrowLeft, Download, RefreshCw, Info } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

import { MOCK_MODEL_EVAL_RESULTS } from '@/data/modelEval';
import type { IModelEvalResult } from '@/types/models';

import EvalMetricsCards from './EvalMetricsCards';
import ConfusionMatrixChart from './ConfusionMatrixChart';
import PrCurveChart from './PrCurveChart';
import ClassificationReportTable from './ClassificationReportTable';

export default function ModelEvalPage() {
  const { versionId } = useParams<{ versionId: string }>();
  const navigate = useNavigate();

  const [selectedVersionId, setSelectedVersionId] = useState(versionId ?? MOCK_MODEL_EVAL_RESULTS[0]?.versionId ?? '');
  const [refreshing, setRefreshing] = useState(false);

  const evalResult: IModelEvalResult | undefined = useMemo(
    () => MOCK_MODEL_EVAL_RESULTS.find((r) => r.versionId === selectedVersionId),
    [selectedVersionId],
  );

  const handleVersionChange = useCallback(
    (value: string) => {
      setSelectedVersionId(value);
      navigate(`/models/eval/${value}`, { replace: true });
    },
    [navigate],
  );

  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await new Promise((r) => setTimeout(r, 800));
      toast.success('评估数据已刷新');
    } finally {
      setRefreshing(false);
    }
  }, []);

  const handleExport = useCallback(() => {
    toast.success('评估报告已导出为 PDF');
  }, []);

  if (!evalResult) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <Info className="size-12 text-muted-foreground/30 mb-4" />
        <p className="text-sm font-medium text-muted-foreground">未找到评估结果</p>
        <p className="text-xs text-muted-foreground/60 mt-1 mb-4">
          请确认模型版本 ID 是否正确
        </p>
        <Button variant="outline" size="sm" onClick={() => navigate('/models')}>
          <ArrowLeft className="mr-1.5 size-3.5" />
          返回模型列表
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 顶部操作栏 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        {/* 左侧：返回 + 标题 */}
        <div className="flex items-center gap-3 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="size-9 shrink-0"
            onClick={() => navigate('/models')}
            aria-label="返回模型列表"
          >
            <ArrowLeft className="size-4" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-lg font-semibold tracking-tight text-foreground truncate">
              模型评估
            </h1>
            <p className="text-xs text-muted-foreground truncate">
              {evalResult.modelName}
            </p>
          </div>
        </div>

        {/* 右侧：版本选择 + 操作按钮 */}
        <div className="flex items-center gap-2 shrink-0">
          <Select value={selectedVersionId} onValueChange={handleVersionChange}>
            <SelectTrigger className="w-[200px] h-9 bg-muted/50 text-sm">
              <SelectValue placeholder="选择版本" />
            </SelectTrigger>
            <SelectContent>
              {MOCK_MODEL_EVAL_RESULTS.map((r) => (
                <SelectItem key={r.versionId} value={r.versionId}>
                  {r.modelName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="size-9"
                  onClick={handleRefresh}
                  disabled={refreshing}
                  aria-label="刷新评估数据"
                >
                  <RefreshCw className={`size-4 ${refreshing ? 'animate-spin' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="bottom">刷新评估数据</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <Button
            variant="outline"
            size="sm"
            className="h-9 gap-1.5"
            onClick={handleExport}
          >
            <Download className="size-3.5" />
            导出报告
          </Button>
        </div>
      </motion.div>

      {/* 评估指标摘要卡片 */}
      <EvalMetricsCards
        accuracy={evalResult.accuracy}
        precision={evalResult.precision}
        recall={evalResult.recall}
        f1Score={evalResult.f1Score}
        aucRoc={evalResult.aucRoc}
      />

      {/* 混淆矩阵 + PR 曲线 并排 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 混淆矩阵 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        >
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                混淆矩阵
              </CardTitle>
              <CardDescription className="text-xs">
                对角线为正确分类，颜色越深数值越大
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ConfusionMatrixChart data={evalResult.confusionMatrix} />
            </CardContent>
          </Card>
        </motion.div>

        {/* PR 曲线 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                Precision-Recall 曲线
              </CardTitle>
              <CardDescription className="text-xs">
                AUC-PR 值越高模型性能越好
              </CardDescription>
            </CardHeader>
            <CardContent>
              <PrCurveChart data={evalResult.prCurve} aucRoc={evalResult.aucRoc} />
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* 分类报告表格 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
      >
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              分类报告
            </CardTitle>
            <CardDescription className="text-xs">
              各类别 Precision / Recall / F1-Score 详细指标
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <ClassificationReportTable data={evalResult.classificationReport} />
          </CardContent>
        </Card>
      </motion.div>

      {/* 模型性能分析洞察 */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
      >
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Info className="size-4 text-primary" />
              性能分析洞察
            </CardTitle>
            <CardDescription className="text-xs">
              基于评估结果自动生成的分析建议
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg bg-muted/30 p-4">
              <p className="text-sm text-foreground leading-relaxed">
                {evalResult.insight}
              </p>
            </div>

            {/* 关键发现标签 */}
            <div className="mt-4 flex flex-wrap gap-2">
              {evalResult.accuracy >= 0.9 && (
                <Badge variant="default" className="bg-success/15 text-success border-success/30 text-xs">
                  ✅ 准确率优秀 (&ge;90%)
                </Badge>
              )}
              {evalResult.accuracy < 0.9 && evalResult.accuracy >= 0.8 && (
                <Badge variant="secondary" className="text-xs">
                  ⚡ 准确率良好 (80-90%)
                </Badge>
              )}
              {evalResult.accuracy < 0.8 && (
                <Badge variant="destructive" className="text-xs">
                  ⚠️ 准确率需提升 (&lt;80%)
                </Badge>
              )}
              {evalResult.f1Score >= 0.9 && (
                <Badge variant="default" className="bg-success/15 text-success border-success/30 text-xs">
                  ✅ F1-Score 优秀 (&ge;0.90)
                </Badge>
              )}
              {evalResult.aucRoc >= 0.95 && (
                <Badge variant="default" className="bg-accent/15 text-accent border-accent/30 text-xs">
                  🏆 AUC-ROC 极高 (&ge;0.95)
                </Badge>
              )}
              {evalResult.recall < evalResult.precision && (
                <Badge variant="outline" className="text-xs border-warning/40 text-warning">
                  📉 召回率偏低，建议增加样本
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
