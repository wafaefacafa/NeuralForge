import ReactECharts from 'echarts-for-react';
import type { EChartsOption, CallbackDataParams } from 'echarts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { IConfusionMatrix } from '@/types/models';

interface ConfusionMatrixChartProps {
  data: IConfusionMatrix;
}

export default function ConfusionMatrixChart({ data }: ConfusionMatrixChartProps) {
  const { labels, matrix } = data;

  const maxVal = Math.max(...matrix.flat(), 1);

  const seriesData: [number, number, number][] = [];
  matrix.forEach((row, i) => {
    row.forEach((val, j) => {
      seriesData.push([j, i, val]);
    });
  });

  const option: EChartsOption = {
    tooltip: {
      trigger: 'item',
      backgroundColor: 'rgba(20, 24, 36, 0.95)',
      borderColor: '#374151',
      textStyle: { color: '#e5e7eb', fontSize: 13 },
      formatter: (params: CallbackDataParams) => {
        const d = params.data as [number, number, number];
        const actualLabel = labels[d[1]];
        const predLabel = labels[d[0]];
        const val = d[2];
        return `<div style="font-size:13px;line-height:1.6">
          <span style="color:#9ca3af">真实:</span> <b>${actualLabel}</b><br/>
          <span style="color:#9ca3af">预测:</span> <b>${predLabel}</b><br/>
          <span style="color:#9ca3af">数量:</span> <b style="color:#06B6D4;font-size:16px">${val}</b>
        </div>`;
      },
    },
    grid: {
      left: '12%',
      right: '8%',
      bottom: '12%',
      top: '6%',
      containLabel: false,
    },
    xAxis: {
      type: 'category',
      data: labels,
      position: 'top',
      axisLine: { lineStyle: { color: '#374151' } },
      axisTick: { show: false },
      axisLabel: {
        color: '#9ca3af',
        fontSize: 11,
        rotate: labels.length > 6 ? 30 : 0,
      },
      name: '预测标签',
      nameLocation: 'center',
      nameGap: 32,
      nameTextStyle: { color: '#6b7280', fontSize: 11 },
    },
    yAxis: {
      type: 'category',
      data: labels,
      inverse: true,
      axisLine: { lineStyle: { color: '#374151' } },
      axisTick: { show: false },
      axisLabel: { color: '#9ca3af', fontSize: 11 },
      name: '真实标签',
      nameLocation: 'center',
      nameGap: 48,
      nameTextStyle: { color: '#6b7280', fontSize: 11 },
    },
    visualMap: {
      min: 0,
      max: maxVal,
      calculable: true,
      orient: 'horizontal',
      left: 'center',
      bottom: 0,
      inRange: {
        color: [
          '#1e293b',
          '#312e81',
          '#4338ca',
          '#4F46E5',
          '#6366f1',
          '#818cf8',
          '#06B6D4',
        ],
      },
      textStyle: { color: '#9ca3af', fontSize: 10 },
      itemWidth: 14,
      itemHeight: 100,
      text: ['高', '低'],
    },
    series: [
      {
        type: 'heatmap',
        data: seriesData,
        label: {
          show: true,
          fontSize: 12,
          fontWeight: 600,
          formatter: (params: CallbackDataParams) => {
            const d = params.data as [number, number, number];
            return String(d[2]);
          },
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 12,
            shadowColor: 'rgba(79, 70, 229, 0.5)',
            borderColor: '#06B6D4',
            borderWidth: 1.5,
          },
        },
        itemStyle: {
          borderColor: '#1f2937',
          borderWidth: 1,
          borderRadius: 3,
        },
      },
    ],
  };

  return (
    <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">混淆矩阵</CardTitle>
      </CardHeader>
      <CardContent>
        <ReactECharts
          option={option}
          theme="ud"
          className="h-[420px] w-full"
          notMerge
          lazyUpdate
        />
      </CardContent>
    </Card>
  );
}
