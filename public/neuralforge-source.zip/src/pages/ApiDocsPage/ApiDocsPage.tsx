import { useState, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Search, Code2, Copy, Check, Play, ChevronRight, ChevronDown, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import { MOCK_API_GROUPS, MOCK_API_ENDPOINTS } from '@/data/apiDocs';
import type { IApiEndpoint, IApiGroup } from '@/types/api';
import { UniversalLink } from '@lark-apaas/client-toolkit-lite';

// ─── 常量 ────────────────────────────────────────────

const METHOD_COLORS: Record<string, string> = {
  GET: 'bg-success/15 text-success border-success/30',
  POST: 'bg-primary/15 text-primary border-primary/30',
  PUT: 'bg-warning/15 text-warning border-warning/30',
  DELETE: 'bg-destructive/15 text-destructive border-destructive/30',
  PATCH: 'bg-accent/15 text-accent border-accent/30',
};

const METHOD_BADGE_VARIANT: Record<string, 'default' | 'secondary' | 'outline' | 'destructive'> = {
  GET: 'default',
  POST: 'default',
  PUT: 'secondary',
  DELETE: 'destructive',
  PATCH: 'outline',
};

// ─── 子组件 ──────────────────────────────────────────

function EndpointNavItem({
  endpoint,
  isActive,
  onClick,
}: {
  endpoint: IApiEndpoint;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full text-left px-3 py-2.5 rounded-lg transition-all duration-200 group ${
        isActive
          ? 'bg-primary/10 border border-primary/20'
          : 'hover:bg-muted/40 border border-transparent'
      }`}
    >
      <div className="flex items-center gap-2 min-w-0">
        <Badge
          variant={METHOD_BADGE_VARIANT[endpoint.method] ?? 'outline'}
          className={`shrink-0 text-[10px] h-5 px-1.5 font-mono leading-none ${
            METHOD_COLORS[endpoint.method] ?? ''
          }`}
        >
          {endpoint.method}
        </Badge>
        <span
          className={`text-xs font-mono truncate ${
            isActive ? 'text-foreground font-medium' : 'text-muted-foreground'
          }`}
        >
          {endpoint.path}
        </span>
      </div>
      <p className="mt-1 text-[11px] text-muted-foreground line-clamp-1 pl-0.5">
        {endpoint.summary}
      </p>
    </button>
  );
}

function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success('已复制到剪贴板');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('复制失败');
    }
  }, [code]);

  return (
    <div className="relative rounded-lg border border-border/40 bg-muted/30 overflow-hidden group">
      {/* 顶部栏 */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-border/20 bg-muted/20">
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-mono">
          {language ?? 'json'}
        </span>
        <Button
          variant="ghost"
          size="icon"
          className="size-6 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={handleCopy}
          aria-label="复制代码"
        >
          {copied ? (
            <Check className="size-3 text-success" />
          ) : (
            <Copy className="size-3" />
          )}
        </Button>
      </div>
      {/* 代码内容 */}
      <pre className="p-3 overflow-x-auto text-xs font-mono text-foreground/85 leading-relaxed whitespace-pre">
        <code>{code}</code>
      </pre>
    </div>
  );
}

function ApiTestDialog({
  open,
  onOpenChange,
  endpoint,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  endpoint: IApiEndpoint | null;
}) {
  const [requestBody, setRequestBody] = useState('');
  const [responseBody, setResponseBody] = useState<string | null>(null);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [sending, setSending] = useState(false);

  const handleSend = useCallback(async () => {
    if (!endpoint) return;
    setSending(true);
    setResponseBody(null);
    setResponseStatus(null);

    try {
      await new Promise((r) => setTimeout(r, 1000 + Math.random() * 500));

      // 模拟响应
      const mockResponse = endpoint.responses[0];
      setResponseStatus(mockResponse?.status ?? 200);
      setResponseBody(mockResponse?.body ?? '{}');
      toast.success(`请求成功 (${mockResponse?.status ?? 200})`);
      logger.info('API test completed:', endpoint.path);
    } catch (err) {
      logger.error('API test failed:', String(err));
      toast.error('请求失败');
      setResponseStatus(500);
      setResponseBody(JSON.stringify({ error: 'Internal Server Error' }, null, 2));
    } finally {
      setSending(false);
    }
  }, [endpoint]);

  const handleClose = useCallback(() => {
    setRequestBody('');
    setResponseBody(null);
    setResponseStatus(null);
    onOpenChange(false);
  }, [onOpenChange]);

  if (!endpoint) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[640px] max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <Play className="size-4 text-primary" />
            API 调用测试
          </DialogTitle>
          <DialogDescription className="flex items-center gap-2">
            <Badge
              variant={METHOD_BADGE_VARIANT[endpoint.method] ?? 'outline'}
              className={`text-[10px] h-5 px-1.5 font-mono ${METHOD_COLORS[endpoint.method] ?? ''}`}
            >
              {endpoint.method}
            </Badge>
            <code className="text-xs font-mono text-foreground">{endpoint.path}</code>
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4">
          {/* 请求参数 */}
          {endpoint.requestParams.length > 0 && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                请求参数
              </Label>
              <div className="space-y-2">
                {endpoint.requestParams.map((param) => (
                  <div key={param.name} className="flex items-center gap-2">
                    <Input
                      placeholder={param.name}
                      className="h-8 text-xs bg-muted/50"
                    />
                    <span className="text-[10px] text-muted-foreground shrink-0 w-16 text-right">
                      {param.type}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 请求体 */}
          {endpoint.requestBody && (
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                请求体 (JSON)
              </Label>
              <Textarea
                value={requestBody || endpoint.requestBody}
                onChange={(e) => setRequestBody(e.target.value)}
                rows={6}
                className="font-mono text-xs bg-muted/50 resize-none"
                placeholder="输入 JSON 请求体..."
              />
            </div>
          )}

          {/* 响应结果 */}
          {responseBody && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="space-y-2"
            >
              <div className="flex items-center gap-2">
                <Label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  响应
                </Label>
                <Badge
                  variant={responseStatus && responseStatus < 400 ? 'default' : 'destructive'}
                  className="text-[10px] h-5 px-1.5"
                >
                  {responseStatus}
                </Badge>
              </div>
              <CodeBlock code={responseBody} language="json" />
            </motion.div>
          )}
        </div>

        <DialogFooter className="gap-2 sm:gap-2 pt-2">
          <Button variant="outline" onClick={handleClose}>
            关闭
          </Button>
          <Button onClick={handleSend} disabled={sending} className="gap-1.5">
            <Play className="size-3.5" />
            {sending ? '发送中...' : '发送请求'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── 主组件 ──────────────────────────────────────────

export default function ApiDocsPage() {
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>(
    MOCK_API_ENDPOINTS[0]?.id ?? '',
  );
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(
    new Set(MOCK_API_GROUPS.map((g) => g.name)),
  );
  const [testDialogOpen, setTestDialogOpen] = useState(false);
  const [testTarget, setTestTarget] = useState<IApiEndpoint | null>(null);

  // 搜索过滤
  const filteredEndpoints = useMemo(() => {
    const kw = searchKeyword.trim().toLowerCase();
    if (!kw) return MOCK_API_ENDPOINTS;
    return MOCK_API_ENDPOINTS.filter(
      (ep) =>
        ep.path.toLowerCase().includes(kw) ||
        ep.summary.toLowerCase().includes(kw) ||
        ep.description.toLowerCase().includes(kw) ||
        ep.group.toLowerCase().includes(kw),
    );
  }, [searchKeyword]);

  // 按分组归类
  const groupedEndpoints = useMemo(() => {
    const map = new Map<string, IApiEndpoint[]>();
    for (const ep of filteredEndpoints) {
      const list = map.get(ep.group) ?? [];
      list.push(ep);
      map.set(ep.group, list);
    }
    return map;
  }, [filteredEndpoints]);

  const selectedEndpoint = useMemo(
    () => MOCK_API_ENDPOINTS.find((ep) => ep.id === selectedEndpointId) ?? null,
    [selectedEndpointId],
  );

  const toggleGroup = useCallback((groupName: string) => {
    setExpandedGroups((prev) => {
      const next = new Set(prev);
      if (next.has(groupName)) {
        next.delete(groupName);
      } else {
        next.add(groupName);
      }
      return next;
    });
  }, []);

  const handleSelectEndpoint = useCallback((id: string) => {
    setSelectedEndpointId(id);
  }, []);

  const handleOpenTest = useCallback((endpoint: IApiEndpoint) => {
    setTestTarget(endpoint);
    setTestDialogOpen(true);
  }, []);

  return (
    <div className="flex h-[calc(100vh-5rem)] gap-0">
      {/* ── 左侧：端点导航 ── */}
      <motion.aside
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="w-72 shrink-0 border-r border-border/40 flex flex-col bg-card/30"
      >
        {/* 搜索框 */}
        <div className="p-3 border-b border-border/30">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              placeholder="搜索 API 端点..."
              className="h-8 bg-muted/40 pl-9 pr-3 text-xs focus-visible:ring-1"
            />
          </div>
        </div>

        {/* 端点列表 */}
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {MOCK_API_GROUPS.map((group) => {
              const endpoints = groupedEndpoints.get(group.name) ?? [];
              const isExpanded = expandedGroups.has(group.name);

              return (
                <Collapsible
                  key={group.name}
                  open={isExpanded}
                  onOpenChange={() => toggleGroup(group.name)}
                >
                  <CollapsibleTrigger className="flex w-full items-center gap-1.5 px-2 py-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-muted/30">
                    {isExpanded ? (
                      <ChevronDown className="size-3.5 shrink-0" />
                    ) : (
                      <ChevronRight className="size-3.5 shrink-0" />
                    )}
                    <span>{group.label}</span>
                    <Badge variant="secondary" className="ml-auto text-[10px] h-4 px-1.5 leading-none">
                      {endpoints.length}
                    </Badge>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-0.5 pb-1">
                    {endpoints.map((ep) => (
                      <EndpointNavItem
                        key={ep.id}
                        endpoint={ep}
                        isActive={selectedEndpointId === ep.id}
                        onClick={() => handleSelectEndpoint(ep.id)}
                      />
                    ))}
                    {endpoints.length === 0 && (
                      <p className="px-3 py-2 text-[11px] text-muted-foreground/60">
                        无匹配端点
                      </p>
                    )}
                  </CollapsibleContent>
                </Collapsible>
              );
            })}
          </div>
        </ScrollArea>
      </motion.aside>

      {/* ── 右侧：端点详情 ── */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="flex-1 overflow-y-auto"
      >
        {selectedEndpoint ? (
          <div className="p-6 space-y-6 max-w-4xl">
            {/* 端点标题 */}
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Badge
                  variant={METHOD_BADGE_VARIANT[selectedEndpoint.method] ?? 'outline'}
                  className={`text-xs h-6 px-2 font-mono font-bold ${
                    METHOD_COLORS[selectedEndpoint.method] ?? ''
                  }`}
                >
                  {selectedEndpoint.method}
                </Badge>
                <h1 className="text-xl font-bold text-foreground font-mono tracking-tight">
                  {selectedEndpoint.path}
                </h1>
              </div>
              <p className="text-sm text-muted-foreground">{selectedEndpoint.summary}</p>
              {selectedEndpoint.description && (
                <p className="text-sm text-muted-foreground/80">{selectedEndpoint.description}</p>
              )}
            </div>

            <Separator />

            {/* 请求参数 */}
            {selectedEndpoint.requestParams.length > 0 && (
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold">请求参数</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="w-full overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="whitespace-nowrap w-[140px]">参数名</TableHead>
                          <TableHead className="whitespace-nowrap w-[100px]">类型</TableHead>
                          <TableHead className="whitespace-nowrap w-[80px]">必填</TableHead>
                          <TableHead className="whitespace-nowrap">描述</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedEndpoint.requestParams.map((param) => (
                          <TableRow key={param.name}>
                            <TableCell>
                              <code className="rounded bg-muted px-1.5 py-0.5 text-xs font-mono text-foreground">
                                {param.name}
                              </code>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-[10px] font-mono">
                                {param.type}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {param.required ? (
                                <Badge
                                  variant="destructive"
                                  className="text-[10px] h-5 px-1.5"
                                >
                                  必填
                                </Badge>
                              ) : (
                                <span className="text-xs text-muted-foreground">可选</span>
                              )}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {param.description}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* 请求体示例 */}
            {selectedEndpoint.requestBody && (
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold">请求体示例</CardTitle>
                </CardHeader>
                <CardContent>
                  <CodeBlock code={selectedEndpoint.requestBody} language="json" />
                </CardContent>
              </Card>
            )}

            {/* 响应示例 */}
            {selectedEndpoint.responses.length > 0 && (
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold">响应示例</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedEndpoint.responses.map((resp, idx) => (
                    <div key={idx} className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant={resp.status < 400 ? 'default' : 'destructive'}
                          className="text-[10px] h-5 px-1.5 font-mono"
                        >
                          {resp.status}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{resp.description}</span>
                      </div>
                      <CodeBlock code={resp.body} language="json" />
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* SDK 代码示例 */}
            {selectedEndpoint.sdkExamples.length > 0 && (
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold">SDK 代码示例</CardTitle>
                  <CardDescription>使用 NeuralForge SDK 调用此 API</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedEndpoint.sdkExamples.map((example, idx) => (
                    <div key={idx} className="space-y-1.5">
                      <Badge variant="secondary" className="text-[10px] h-5 px-1.5 font-mono">
                        {example.language}
                      </Badge>
                      <CodeBlock code={example.code} language={example.language} />
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* 底部操作栏 */}
            <div className="flex items-center gap-3 pt-2">
              <Button
                onClick={() => handleOpenTest(selectedEndpoint)}
                className="gap-1.5"
              >
                <Play className="size-4" />
                Try it - 在线测试
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5" asChild>
                <UniversalLink to="#" onClick={(e) => { e.preventDefault(); toast.info('API 文档已复制链接'); }}>
                  <ExternalLink className="size-3.5" />
                  复制链接
                </UniversalLink>
              </Button>
            </div>
          </div>
        ) : (
          /* 空状态 */
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="flex size-16 items-center justify-center rounded-2xl bg-muted/30 mb-4">
              <Code2 className="size-8 text-muted-foreground/40" />
            </div>
            <p className="text-sm font-medium text-muted-foreground">选择一个 API 端点</p>
            <p className="text-xs text-muted-foreground/60 mt-1">
              从左侧导航中选择端点以查看详细信息
            </p>
          </div>
        )}
      </motion.div>

      {/* 测试对话框 */}
      <ApiTestDialog
        open={testDialogOpen}
        onOpenChange={setTestDialogOpen}
        endpoint={testTarget}
      />
    </div>
  );
}
