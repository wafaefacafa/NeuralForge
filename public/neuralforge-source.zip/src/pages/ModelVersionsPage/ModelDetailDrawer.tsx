import { memo } from 'react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Cpu,
  HardDrive,
  Layers,
  Zap,
  Clock,
  Hash,
  BrainCircuit,
} from 'lucide-react';
import type { IModelVersion } from '@/types/models';

interface ModelDetailDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  version: IModelVersion | null;
}

function ModelDetailDrawer({ open, onOpenChange, version }: ModelDetailDrawerProps) {
  if (!version) return null;

  const statusVariant = (() => {
    switch (version.status) {
      case 'ready':
        return 'default' as const;
      case 'deployed':
        return 'secondary' as const;
      case 'training':
        return 'outline' as const;
      case 'failed':
        return 'destructive' as const;
      default:
        return 'outline' as const;
    }
  })();

  const statusLabel = (() => {
    switch (version.status) {
      case 'ready':
        return '就绪';
      case 'deployed':
        return '已部署';
      case 'training':
        return '训练中';
      case 'failed':
        return '失败';
      default:
        return version.status;
    }
  })();

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg flex flex-col p-0">
        <SheetHeader className="px-6 pt-6 pb-4 border-b border-border/40">
          <div className="flex items-center gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/15">
              <BrainCircuit className="size-5 text-primary" />
            </div>
            <div className="min-w-0 flex-1">
              <SheetTitle className="text-base font-semibold truncate">
                {version.modelName}
              </SheetTitle>
              <SheetDescription className="text-xs mt-0.5">
                版本 {version.version}
              </SheetDescription>
            </div>
            <Badge variant={statusVariant} className="shrink-0 text-xs">
              {statusLabel}
            </Badge>
          </div>
        </SheetHeader>

        <ScrollArea className="flex-1">
          <div className="px-6 py-5 space-y-6">
            {/* 基本信息 */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                基本信息
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <InfoItem
                  icon={Layers}
                  label="框架"
                  value={version.framework}
                />
                <InfoItem
                  icon={Hash}
                  label="版本号"
                  value={version.version}
                />
                <InfoItem
                  icon={Clock}
                  label="创建时间"
                  value={formatDate(version.createdAt)}
                />
                <InfoItem
                  icon={HardDrive}
                  label="模型大小"
                  value={`${version.sizeMB} MB`}
                />
              </div>
            </div>

            <Separator />

            {/* 模型指标 */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                模型指标
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <MetricCard label="Accuracy" value={version.accuracy} unit="%" color="text-success" />
                <MetricCard label="F1 Score" value={version.f1Score} unit="" color="text-primary" />
                <MetricCard label="Precision" value={version.precision} unit="" color="text-accent" />
                <MetricCard label="Recall" value={version.recall} unit="" color="text-chart-3" />
              </div>
            </div>

            <Separator />

            {/* 超参数 */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                超参数
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <InfoItem
                  icon={Zap}
                  label="学习率"
                  value={String(version.hyperparams.learningRate)}
                />
                <InfoItem
                  icon={Layers}
                  label="Batch Size"
                  value={String(version.hyperparams.batchSize)}
                />
                <InfoItem
                  icon={Hash}
                  label="Epochs"
                  value={String(version.hyperparams.epochs)}
                />
                <InfoItem
                  icon={BrainCircuit}
                  label="优化器"
                  value={version.hyperparams.optimizer}
                />
              </div>
            </div>

            <Separator />

            {/* 训练环境 */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                训练环境
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <InfoItem
                  icon={Cpu}
                  label="GPU 型号"
                  value={version.trainingEnv.gpuType}
                />
                <InfoItem
                  icon={Layers}
                  label="GPU 数量"
                  value={`${version.trainingEnv.gpuCount} 卡`}
                />
                <InfoItem
                  icon={HardDrive}
                  label="内存"
                  value={`${version.trainingEnv.memoryGB} GB`}
                />
              </div>
            </div>

            <Separator />

            {/* 项目信息 */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                所属项目
              </h4>
              <div className="rounded-lg border border-border/40 bg-card/50 p-3">
                <div className="text-sm font-medium">{version.projectName}</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  ID: {version.projectId}
                </div>
              </div>
            </div>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

/* ---------- 子组件 ---------- */

function InfoItem({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-border/30 bg-muted/30 px-3 py-2.5">
      <Icon className="size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0 flex-1">
        <div className="text-[11px] text-muted-foreground leading-tight">{label}</div>
        <div className="text-sm font-medium truncate">{value}</div>
      </div>
    </div>
  );
}

function MetricCard({
  label,
  value,
  unit,
  color,
}: {
  label: string;
  value: number;
  unit: string;
  color: string;
}) {
  return (
    <div className="rounded-lg border border-border/30 bg-muted/30 px-3 py-2.5">
      <div className="text-[11px] text-muted-foreground leading-tight">{label}</div>
      <div className={`text-lg font-bold tabular-nums ${color}`}>
        {value.toFixed(3)}
        {unit && <span className="text-xs font-normal ml-0.5">{unit}</span>}
      </div>
    </div>
  );
}

/* ---------- 工具函数 ---------- */

function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export default memo(ModelDetailDrawer);
