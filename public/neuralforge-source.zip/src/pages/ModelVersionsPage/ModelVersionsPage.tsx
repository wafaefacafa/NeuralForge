import { useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import {
  Search,
  Filter,
  GitCompare,
  Eye,
  Rocket,
  Download,
  Trash2,
  ChevronDown,
  X,
  ArrowUpDown,
  BarChart3,
  Cpu,
  Clock,
  Layers,
  Target,
  BrainCircuit,
  HardDrive,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Play,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

import { MOCK_MODEL_VERSIONS } from '@/data/modelVersions';
import type { IModelVersion } from '@/types/models';

// ============================================================
// 状态映射
// ============================================================
const STATUS_CONFIG: Record<
  IModelVersion['status'],
  { label: string; variant: 'default' | 'secondary' | 'outline' | 'destructive'; icon: React.ComponentType<{ className?: string }>; className: string }
> = {
  ready: {
    label: '就绪',
    variant: 'default',
    icon: CheckCircle2,
    className: 'bg-success/15 text-success border-success/30',
  },
  training: {
    label: '训练中',
    variant: 'secondary',
    icon: Play,
    className: 'bg-primary/15 text-primary border-primary/30',
  },
  failed: {
    label: '失败',
    variant: 'destructive',
    icon: XCircle,
    className: 'bg-destructive/15 text-destructive border-destructive/30',
  },
  deployed: {
    label: '已部署',
    variant: 'outline',
    icon: Rocket,
    className: 'bg-accent/15 text-accent border-accent/30',
  },
};

const FRAMEWORK_COLORS: Record<string, string> = {
  PyTorch: 'bg-orange-500/15 text-orange-400 border-orange-500/30',
  TensorFlow: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30',
  JAX: 'bg-blue-400/15 text-blue-400 border-blue-400/30',
};

// ============================================================
// 指标进度条组件
// ============================================================
function MetricBar({ label, value, color }: { label: string; value: number; color: string }) {
  const pct = Math.round(value * 100);
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono font-semibold tabular-nums" style={{ color }}>
          {pct}%
        </span>
      </div>
      <Progress value={pct} className="h-1.5" indicatorClassName={color === '#4F46E5' ? 'bg-primary' : color === '#06B6D4' ? 'bg-accent' : color === '#22C55E' ? 'bg-success' : 'bg-warning'} />
    </div>
  );
}

// ============================================================
// 版本对比抽屉
// ============================================================
function VersionCompareDrawer({
  open,
  onOpenChange,
  versionA,
  versionB,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  versionA: IModelVersion | null;
  versionB: IModelVersion | null;
}) {
  if (!versionA || !versionB) return null;

  const metrics = [
    { label: 'Accuracy', key: 'accuracy' as const, format: (v: number) => `${(v * 100).toFixed(1)}%` },
    { label: 'F1 Score', key: 'f1Score' as const, format: (v: number) => `${(v * 100).toFixed(1)}%` },
    { label: 'Precision', key: 'precision' as const, format: (v: number) => `${(v * 100).toFixed(1)}%` },
    { label: 'Recall', key: 'recall' as const, format: (v: number) => `${(v * 100).toFixed(1)}%` },
    { label: '模型大小', key: 'sizeMB' as const, format: (v: number) => `${v.toFixed(1)} MB` },
  ];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-[640px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <GitCompare className="size-5 text-primary" />
            版本对比
          </SheetTitle>
          <SheetDescription>
            对比 {versionA.version} 与 {versionB.version} 的模型指标
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* 版本信息卡片 */}
          <div className="grid grid-cols-2 gap-4">
            {[versionA, versionB].map((v, idx) => {
              const StatusIcon = STATUS_CONFIG[v.status].icon;
              return (
                <Card key={v.id} className={`border-border/40 bg-card/60 ${idx === 0 ? 'border-l-4 border-l-primary' : 'border-l-4 border-l-accent'}`}>
                  <CardContent className="p-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs font-mono">{v.version}</Badge>
                      <Badge className={`text-[10px] ${STATUS_CONFIG[v.status].className}`}>
                        <StatusIcon className="mr-1 size-3" />
                        {STATUS_CONFIG[v.status].label}
                      </Badge>
                    </div>
                    <p className="text-sm font-semibold truncate">{v.modelName}</p>
                    <p className="text-xs text-muted-foreground">{v.projectName}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* 指标对比表格 */}
          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <BarChart3 className="size-4 text-primary" />
                指标对比
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="whitespace-nowrap">指标</TableHead>
                      <TableHead className="whitespace-nowrap text-right">{versionA.version}</TableHead>
                      <TableHead className="whitespace-nowrap text-right">{versionB.version}</TableHead>
                      <TableHead className="whitespace-nowrap text-right">差异</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {metrics.map((m) => {
                      const valA = versionA[m.key] as number;
                      const valB = versionB[m.key] as number;
                      const diff = valA - valB;
                      const isBetter = m.key === 'sizeMB' ? diff < 0 : diff > 0;
                      const isEqual = Math.abs(diff) < 0.001;

                      return (
                        <TableRow key={m.key}>
                          <TableCell className="font-medium text-sm whitespace-nowrap">{m.label}</TableCell>
                          <TableCell className="text-right font-mono text-sm tabular-nums">{m.format(valA)}</TableCell>
                          <TableCell className="text-right font-mono text-sm tabular-nums">{m.format(valB)}</TableCell>
                          <TableCell className="text-right">
                            {isEqual ? (
                              <span className="text-xs text-muted-foreground">-</span>
                            ) : (
                              <span
                                className={`text-xs font-mono font-semibold tabular-nums ${
                                  isBetter ? 'text-success' : 'text-destructive'
                                }`}
                              >
                                {isBetter ? '↑' : '↓'} {m.format(Math.abs(diff))}
                              </span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* 超参数对比 */}
          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Cpu className="size-4 text-primary" />
                超参数对比
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="whitespace-nowrap">参数</TableHead>
                      <TableHead className="whitespace-nowrap text-right">{versionA.version}</TableHead>
                      <TableHead className="whitespace-nowrap text-right">{versionB.version}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell className="text-sm text-muted-foreground">学习率</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionA.hyperparams.learningRate}</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionB.hyperparams.learningRate}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-sm text-muted-foreground">Batch Size</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionA.hyperparams.batchSize}</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionB.hyperparams.batchSize}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-sm text-muted-foreground">Epochs</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionA.hyperparams.epochs}</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionB.hyperparams.epochs}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="text-sm text-muted-foreground">优化器</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionA.hyperparams.optimizer}</TableCell>
                      <TableCell className="text-right font-mono text-sm">{versionB.hyperparams.optimizer}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// ============================================================
// 模型详情抽屉
// ============================================================
function ModelDetailDrawer({
  open,
  onOpenChange,
  version,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  version: IModelVersion | null;
}) {
  if (!version) return null;

  const StatusIcon = STATUS_CONFIG[version.status].icon;

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-[560px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Eye className="size-5 text-primary" />
            模型详情
          </SheetTitle>
          <SheetDescription>
            版本 {version.version} 的完整信息
          </SheetDescription>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* 基本信息 */}
          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Layers className="size-4 text-primary" />
                基本信息
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">模型名称</span>
                <span className="text-sm font-semibold">{version.modelName}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">所属项目</span>
                <span className="text-sm">{version.projectName}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">框架</span>
                <Badge variant="outline" className={`text-xs ${FRAMEWORK_COLORS[version.framework] ?? ''}`}>
                  {version.framework}
                </Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">状态</span>
                <Badge className={`text-xs ${STATUS_CONFIG[version.status].className}`}>
                  <StatusIcon className="mr-1 size-3" />
                  {STATUS_CONFIG[version.status].label}
                </Badge>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">模型大小</span>
                <span className="text-sm font-mono tabular-nums">{version.sizeMB.toFixed(1)} MB</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">创建时间</span>
                <span className="text-sm font-mono tabular-nums">
                  {new Date(version.createdAt).toLocaleString('zh-CN')}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* 模型指标 */}
          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="size-4 text-primary" />
                模型指标
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <MetricBar label="Accuracy" value={version.accuracy} color="#4F46E5" />
              <MetricBar label="F1 Score" value={version.f1Score} color="#06B6D4" />
              <MetricBar label="Precision" value={version.precision} color="#22C55E" />
              <MetricBar label="Recall" value={version.recall} color="#A855F7" />
            </CardContent>
          </Card>

          {/* 超参数 */}
          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Cpu className="size-4 text-primary" />
                超参数
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">学习率</span>
                <span className="text-sm font-mono">{version.hyperparams.learningRate}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Batch Size</span>
                <span className="text-sm font-mono">{version.hyperparams.batchSize}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Epochs</span>
                <span className="text-sm font-mono">{version.hyperparams.epochs}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">优化器</span>
                <span className="text-sm font-mono">{version.hyperparams.optimizer}</span>
              </div>
            </CardContent>
          </Card>

          {/* 训练环境 */}
          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <HardDrive className="size-4 text-primary" />
                训练环境
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">GPU 型号</span>
                <span className="text-sm font-medium">{version.trainingEnv.gpuType}</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">GPU 数量</span>
                <span className="text-sm font-mono">{version.trainingEnv.gpuCount} 卡</span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">内存</span>
                <span className="text-sm font-mono">{version.trainingEnv.memoryGB} GB</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// ============================================================
// 主页面组件
// ============================================================
export default function ModelVersionsPage() {
  const navigate = useNavigate();

  // 数据
  const [versions] = useState<IModelVersion[]>(MOCK_MODEL_VERSIONS);

  // 筛选状态
  const [searchKeyword, setSearchKeyword] = useState('');
  const [frameworkFilter, setFrameworkFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortField, setSortField] = useState<'accuracy' | 'f1Score' | 'createdAt' | 'sizeMB'>('createdAt');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // 对比状态
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [compareOpen, setCompareOpen] = useState(false);

  // 详情状态
  const [detailVersion, setDetailVersion] = useState<IModelVersion | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);

  // 删除状态
  const [deleteTarget, setDeleteTarget] = useState<IModelVersion | null>(null);

  // 筛选后的数据
  const filteredVersions = useMemo(() => {
    let result = [...versions];

    // 搜索
    if (searchKeyword.trim()) {
      const kw = searchKeyword.trim().toLowerCase();
      result = result.filter(
        (v) =>
          v.modelName.toLowerCase().includes(kw) ||
          v.version.toLowerCase().includes(kw) ||
          v.projectName.toLowerCase().includes(kw),
      );
    }

    // 框架筛选
    if (frameworkFilter !== 'all') {
      result = result.filter((v) => v.framework === frameworkFilter);
    }

    // 状态筛选
    if (statusFilter !== 'all') {
      result = result.filter((v) => v.status === statusFilter);
    }

    // 排序
    result.sort((a, b) => {
      let cmp = 0;
      if (sortField === 'createdAt') {
        cmp = new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      } else {
        cmp = (a[sortField] as number) - (b[sortField] as number);
      }
      return sortOrder === 'desc' ? -cmp : cmp;
    });

    return result;
  }, [versions, searchKeyword, frameworkFilter, statusFilter, sortField, sortOrder]);

  // 切换排序
  const handleSort = useCallback(
    (field: typeof sortField) => {
      if (sortField === field) {
        setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'));
      } else {
        setSortField(field);
        setSortOrder('desc');
      }
    },
    [sortField],
  );

  // 切换选中
  const handleToggleSelect = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        if (next.size >= 2) {
          toast.info('最多选择 2 个版本进行对比');
          return prev;
        }
        next.add(id);
      }
      return next;
    });
  }, []);

  // 打开对比
  const handleCompare = useCallback(() => {
    const ids = Array.from(selectedIds);
    if (ids.length !== 2) {
      toast.info('请选择 2 个版本进行对比');
      return;
    }
    setCompareOpen(true);
  }, [selectedIds]);

  // 获取选中的版本
  const selectedVersions = useMemo(() => {
    const ids = Array.from(selectedIds);
    return ids.map((id) => versions.find((v) => v.id === id)).filter(Boolean) as IModelVersion[];
  }, [selectedIds, versions]);

  // 查看详情
  const handleViewDetail = useCallback((version: IModelVersion) => {
    setDetailVersion(version);
    setDetailOpen(true);
  }, []);

  // 部署
  const handleDeploy = useCallback(
    (version: IModelVersion) => {
      navigate(`/deploy/config/${version.id}`);
    },
    [navigate],
  );

  // 评估
  const handleEvaluate = useCallback(
    (version: IModelVersion) => {
      navigate(`/models/eval/${version.id}`);
    },
    [navigate],
  );

  // 下载
  const handleDownload = useCallback((version: IModelVersion) => {
    toast.success(`开始下载模型 ${version.version}`);
    logger.info('Model download started:', version.id);
  }, []);

  // 删除
  const handleDelete = useCallback(() => {
    if (!deleteTarget) return;
    toast.success(`模型版本 ${deleteTarget.version} 已删除`);
    logger.info('Model version deleted:', deleteTarget.id);
    setDeleteTarget(null);
  }, [deleteTarget]);

  // 清除筛选
  const handleClearFilters = useCallback(() => {
    setSearchKeyword('');
    setFrameworkFilter('all');
    setStatusFilter('all');
  }, []);

  const hasActiveFilters = searchKeyword.trim() !== '' || frameworkFilter !== 'all' || statusFilter !== 'all';

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h1 className="text-xl font-bold tracking-tight text-foreground">模型版本管理</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            管理所有模型版本，对比指标，部署上线
          </p>
        </div>
        <div className="flex items-center gap-2 mt-2 sm:mt-0">
          {selectedIds.size === 2 && (
            <Button size="sm" className="gap-1.5" onClick={handleCompare}>
              <GitCompare className="size-4" />
              对比版本
            </Button>
          )}
          {selectedIds.size === 1 && (
            <span className="text-xs text-muted-foreground">再选 1 个版本进行对比</span>
          )}
        </div>
      </motion.div>

      {/* 搜索与筛选栏 */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.05 }}
      >
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              {/* 搜索框 */}
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  placeholder="搜索模型名称、版本号、项目..."
                  className="bg-muted/50 pl-9 pr-9"
                />
                {searchKeyword && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="!absolute right-1 top-1/2 z-20 h-7 w-7 -translate-y-1/2"
                    onClick={() => setSearchKeyword('')}
                    aria-label="清除搜索"
                  >
                    <X className="size-3.5" />
                  </Button>
                )}
              </div>

              {/* 框架筛选 */}
              <Select value={frameworkFilter} onValueChange={setFrameworkFilter}>
                <SelectTrigger className="w-full sm:w-[150px] bg-muted/50">
                  <Filter className="mr-2 size-3.5 text-muted-foreground" />
                  <SelectValue placeholder="框架" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部框架</SelectItem>
                  <SelectItem value="PyTorch">PyTorch</SelectItem>
                  <SelectItem value="TensorFlow">TensorFlow</SelectItem>
                  <SelectItem value="JAX">JAX</SelectItem>
                </SelectContent>
              </Select>

              {/* 状态筛选 */}
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[140px] bg-muted/50">
                  <SelectValue placeholder="状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="ready">就绪</SelectItem>
                  <SelectItem value="training">训练中</SelectItem>
                  <SelectItem value="deployed">已部署</SelectItem>
                  <SelectItem value="failed">失败</SelectItem>
                </SelectContent>
              </Select>

              {/* 清除筛选 */}
              {hasActiveFilters && (
                <Button variant="ghost" size="sm" className="shrink-0 gap-1" onClick={handleClearFilters}>
                  <X className="size-3.5" />
                  清除
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* 版本列表表格 */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
      >
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-semibold flex items-center gap-2">
                <BrainCircuit className="size-4 text-primary" />
                版本列表
                <Badge variant="secondary" className="text-[10px] ml-1">
                  {filteredVersions.length} 个版本
                </Badge>
              </CardTitle>
              {selectedIds.size > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs gap-1"
                  onClick={() => setSelectedIds(new Set())}
                >
                  <X className="size-3" />
                  取消选择
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {filteredVersions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <BrainCircuit className="size-12 text-muted-foreground/30 mb-4" />
                <p className="text-sm font-medium text-muted-foreground">未找到匹配的模型版本</p>
                <p className="text-xs text-muted-foreground/60 mt-1 mb-4">
                  尝试调整搜索关键词或筛选条件
                </p>
                <Button variant="outline" size="sm" onClick={handleClearFilters}>
                  清除所有筛选
                </Button>
              </div>
            ) : (
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-10 whitespace-nowrap">
                        <span className="sr-only">对比选择</span>
                      </TableHead>
                      <TableHead className="whitespace-nowrap">版本号</TableHead>
                      <TableHead className="whitespace-nowrap">模型名称</TableHead>
                      <TableHead className="whitespace-nowrap">框架</TableHead>
                      <TableHead className="whitespace-nowrap">
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
                          onClick={() => handleSort('accuracy')}
                        >
                          Accuracy
                          <ArrowUpDown className="size-3" />
                        </button>
                      </TableHead>
                      <TableHead className="whitespace-nowrap">
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
                          onClick={() => handleSort('f1Score')}
                        >
                          F1 Score
                          <ArrowUpDown className="size-3" />
                        </button>
                      </TableHead>
                      <TableHead className="whitespace-nowrap">
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
                          onClick={() => handleSort('sizeMB')}
                        >
                          大小
                          <ArrowUpDown className="size-3" />
                        </button>
                      </TableHead>
                      <TableHead className="whitespace-nowrap">状态</TableHead>
                      <TableHead className="whitespace-nowrap">
                        <button
                          type="button"
                          className="inline-flex items-center gap-1 hover:text-foreground transition-colors"
                          onClick={() => handleSort('createdAt')}
                        >
                          创建时间
                          <ArrowUpDown className="size-3" />
                        </button>
                      </TableHead>
                      <TableHead className="whitespace-nowrap text-right">操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredVersions.map((version, idx) => {
                      const StatusIcon = STATUS_CONFIG[version.status].icon;
                      const isSelected = selectedIds.has(version.id);

                      return (
                        <TableRow
                          key={version.id}
                          className={`transition-colors ${isSelected ? 'bg-primary/5' : ''}`}
                        >
                          {/* 对比选择 */}
                          <TableCell>
                            <Checkbox
                              checked={isSelected}
                              onCheckedChange={() => handleToggleSelect(version.id)}
                              aria-label={`选择 ${version.version} 进行对比`}
                            />
                          </TableCell>

                          {/* 版本号 */}
                          <TableCell>
                            <Badge variant="outline" className="font-mono text-xs">
                              {version.version}
                            </Badge>
                          </TableCell>

                          {/* 模型名称 */}
                          <TableCell className="font-medium">
                            <div className="flex flex-col gap-0.5">
                              <span className="truncate max-w-[180px] text-sm">{version.modelName}</span>
                              <span className="text-[11px] text-muted-foreground truncate max-w-[180px]">
                                {version.projectName}
                              </span>
                            </div>
                          </TableCell>

                          {/* 框架 */}
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={`text-[10px] ${FRAMEWORK_COLORS[version.framework] ?? ''}`}
                            >
                              {version.framework}
                            </Badge>
                          </TableCell>

                          {/* Accuracy */}
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress
                                value={version.accuracy * 100}
                                className="h-1.5 w-12"
                                indicatorClassName="bg-primary"
                              />
                              <span className="text-sm font-mono font-semibold tabular-nums">
                                {(version.accuracy * 100).toFixed(1)}%
                              </span>
                            </div>
                          </TableCell>

                          {/* F1 Score */}
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress
                                value={version.f1Score * 100}
                                className="h-1.5 w-12"
                                indicatorClassName="bg-accent"
                              />
                              <span className="text-sm font-mono font-semibold tabular-nums">
                                {(version.f1Score * 100).toFixed(1)}%
                              </span>
                            </div>
                          </TableCell>

                          {/* 大小 */}
                          <TableCell>
                            <span className="text-sm font-mono tabular-nums text-muted-foreground">
                              {version.sizeMB.toFixed(1)} MB
                            </span>
                          </TableCell>

                          {/* 状态 */}
                          <TableCell>
                            <Badge className={`text-[10px] ${STATUS_CONFIG[version.status].className}`}>
                              <StatusIcon className="mr-1 size-3" />
                              {STATUS_CONFIG[version.status].label}
                            </Badge>
                          </TableCell>

                          {/* 创建时间 */}
                          <TableCell className="whitespace-nowrap">
                            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                              <Clock className="size-3" />
                              {new Date(version.createdAt).toLocaleDateString('zh-CN', {
                                month: '2-digit',
                                day: '2-digit',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </div>
                          </TableCell>

                          {/* 操作 */}
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              {/* 查看详情 */}
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="size-8"
                                      onClick={() => handleViewDetail(version)}
                                      aria-label="查看详情"
                                    >
                                      <Eye className="size-3.5" />
                                    </Button>
                                  </TooltipTrigger>
                                  <TooltipContent side="top">查看详情</TooltipContent>
                                </Tooltip>
                              </TooltipProvider>

                              {/* 更多操作下拉 */}
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="size-8" aria-label="更多操作">
                                    <ChevronDown className="size-3.5" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-40">
                                  <DropdownMenuItem
                                    onClick={() => handleDeploy(version)}
                                    className="cursor-pointer"
                                  >
                                    <Rocket className="mr-2 size-4" />
                                    部署
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => handleEvaluate(version)}
                                    className="cursor-pointer"
                                  >
                                    <BarChart3 className="mr-2 size-4" />
                                    评估
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => handleDownload(version)}
                                    className="cursor-pointer"
                                  >
                                    <Download className="mr-2 size-4" />
                                    下载
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => setDeleteTarget(version)}
                                    className="cursor-pointer text-destructive focus:text-destructive"
                                  >
                                    <Trash2 className="mr-2 size-4" />
                                    删除
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* 版本对比抽屉 */}
      <VersionCompareDrawer
        open={compareOpen}
        onOpenChange={setCompareOpen}
        versionA={selectedVersions[0] ?? null}
        versionB={selectedVersions[1] ?? null}
      />

      {/* 模型详情抽屉 */}
      <ModelDetailDrawer
        open={detailOpen}
        onOpenChange={setDetailOpen}
        version={detailVersion}
      />

      {/* 删除确认对话框 */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Trash2 className="size-5 text-destructive" />
              删除模型版本
            </AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除模型版本「{deleteTarget?.version} - {deleteTarget?.modelName}」吗？此操作不可撤销，已部署的实例将不受影响。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
