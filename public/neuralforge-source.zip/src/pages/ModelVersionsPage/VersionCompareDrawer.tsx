import { useMemo } from 'react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { ArrowUp, ArrowDown, Minus } from 'lucide-react';

import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { CHART_COLORS } from '@/lib/chart-colors';
import type { IModelVersion } from '@/types/models';

interface VersionCompareDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  versionA: IModelVersion;
  versionB: IModelVersion;
}

const METRIC_LABELS: Record<string, string> = {
  accuracy: 'Accuracy',
  f1Score: 'F1 Score',
  precision: 'Precision',
  recall: 'Recall',
  sizeMB: '模型大小 (MB)',
};

const METRIC_FORMAT: Record<string, (v: number) => string> = {
  accuracy: (v) => `${(v * 100).toFixed(1)}%`,
  f1Score: (v) => v.toFixed(4),
  precision: (v) => v.toFixed(4),
  recall: (v) => v.toFixed(4),
  sizeMB: (v) => `${v} MB`,
};

const METRIC_HIGHER_BETTER: Record<string, boolean> = {
  accuracy: true,
  f1Score: true,
  precision: true,
  recall: true,
  sizeMB: false,
};

const STATUS_VARIANT: Record<string, 'default' | 'secondary' | 'outline' | 'destructive'> = {
  ready: 'secondary',
  training: 'default',
  failed: 'destructive',
  deployed: 'outline',
};

const STATUS_LABEL: Record<string, string> = {
  ready: '就绪',
  training: '训练中',
  failed: '失败',
  deployed: '已部署',
};

function DiffBadge({ valueA, valueB, metric }: { valueA: number; valueB: number; metric: string }) {
  const higherBetter = METRIC_HIGHER_BETTER[metric] ?? true;
  const diff = valueA - valueB;

  if (Math.abs(diff) < 0.0001) {
    return (
      <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
        <Minus className="size-3" />
        持平
      </span>
    );
  }

  const isUp = diff > 0;
  const isGood = higherBetter ? isUp : !isUp;
  const colorClass = isGood ? 'text-success' : 'text-destructive';

  const pctMetric = ['accuracy', 'f1Score', 'precision', 'recall'].includes(metric);
  const diffStr = pctMetric
    ? `${(diff * 100).toFixed(2)}pp`
    : `${diff > 0 ? '+' : ''}${diff.toFixed(1)} MB`;

  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium ${colorClass}`}>
      {isUp ? <ArrowUp className="size-3" /> : <ArrowDown className="size-3" />}
      {diffStr}
    </span>
  );
}

export default function VersionCompareDrawer({
  open,
  onOpenChange,
  versionA,
  versionB,
}: VersionCompareDrawerProps) {
  const metrics = useMemo(() => ['accuracy', 'f1Score', 'precision', 'recall', 'sizeMB'] as const, []);

  const chartOption: EChartsOption = useMemo(
    () => ({
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(20,20,30,0.95)',
        borderColor: '#333',
        textStyle: { color: '#e0e0e0', fontSize: 12 },
      },
      legend: {
        bottom: 0,
        textStyle: { color: '#999', fontSize: 11 },
        data: [versionA.version, versionB.version],
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '20%',
        top: '8%',
        containLabel: true,
      },
      xAxis: {
        type: 'category',
        data: ['Accuracy', 'F1 Score', 'Precision', 'Recall'],
        axisLabel: { color: '#999', fontSize: 11 },
        axisLine: { lineStyle: { color: '#333' } },
      },
      yAxis: {
        type: 'value',
        min: 0.8,
        max: 1,
        axisLabel: {
          color: '#999',
          fontSize: 11,
          formatter: (value: number) => `${(value * 100).toFixed(0)}%`,
        },
        splitLine: { lineStyle: { color: '#222' } },
      },
      color: [CHART_COLORS[0], CHART_COLORS[1]],
      series: [
        {
          name: versionA.version,
          type: 'bar',
          barWidth: '35%',
          barGap: '20%',
          data: [versionA.accuracy, versionA.f1Score, versionA.precision, versionA.recall],
          itemStyle: {
            borderRadius: [4, 4, 0, 0],
          },
          label: {
            show: true,
            position: 'top',
            fontSize: 10,
            formatter: (p: { value: number }) => `${(p.value * 100).toFixed(1)}%`,
          },
        },
        {
          name: versionB.version,
          type: 'bar',
          barWidth: '35%',
          data: [versionB.accuracy, versionB.f1Score, versionB.precision, versionB.recall],
          itemStyle: {
            borderRadius: [4, 4, 0, 0],
          },
          label: {
            show: true,
            position: 'top',
            fontSize: 10,
            formatter: (p: { value: number }) => `${(p.value * 100).toFixed(1)}%`,
          },
        },
      ],
    }),
    [versionA, versionB],
  );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-2xl lg:max-w-3xl overflow-y-auto">
        <SheetHeader className="mb-6">
          <SheetTitle className="text-lg font-semibold">版本对比</SheetTitle>
          <SheetDescription>
            对比 {versionA.modelName} 的两个版本
          </SheetDescription>
        </SheetHeader>

        {/* 版本概览 */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="rounded-lg border border-border bg-card/50 p-4">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="outline" className="text-xs font-mono">
                {versionA.version}
              </Badge>
              <Badge variant={STATUS_VARIANT[versionA.status] as 'default'}>
                {STATUS_LABEL[versionA.status]}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground">
              <div>框架: {versionA.framework}</div>
              <div>创建: {new Date(versionA.createdAt).toLocaleDateString('zh-CN')}</div>
            </div>
          </div>

          <div className="rounded-lg border border-border bg-card/50 p-4">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="outline" className="text-xs font-mono">
                {versionB.version}
              </Badge>
              <Badge variant={STATUS_VARIANT[versionB.status] as 'default'}>
                {STATUS_LABEL[versionB.status]}
              </Badge>
            </div>
            <div className="text-xs text-muted-foreground">
              <div>框架: {versionB.framework}</div>
              <div>创建: {new Date(versionB.createdAt).toLocaleDateString('zh-CN')}</div>
            </div>
          </div>
        </div>

        {/* 柱状图对比 */}
        <div className="rounded-lg border border-border bg-card/50 p-4 mb-6">
          <h4 className="text-sm font-medium mb-3">核心指标对比</h4>
          <ReactECharts option={chartOption} theme="ud" className="h-[280px]" />
        </div>

        {/* 指标对比表 */}
        <div className="rounded-lg border border-border overflow-hidden mb-6">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-[120px] whitespace-nowrap">指标</TableHead>
                <TableHead className="whitespace-nowrap text-right">{versionA.version}</TableHead>
                <TableHead className="whitespace-nowrap text-right">{versionB.version}</TableHead>
                <TableHead className="whitespace-nowrap text-right">差异</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {metrics.map((metric) => {
                const valA = versionA[metric];
                const valB = versionB[metric];
                return (
                  <TableRow key={metric} className="border-border">
                    <TableCell className="font-medium whitespace-nowrap text-sm">
                      {METRIC_LABELS[metric]}
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-sm">
                      {METRIC_FORMAT[metric](valA)}
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-sm">
                      {METRIC_FORMAT[metric](valB)}
                    </TableCell>
                    <TableCell className="text-right">
                      <DiffBadge valueA={valA} valueB={valB} metric={metric} />
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* 超参数对比 */}
        <div className="rounded-lg border border-border overflow-hidden mb-6">
          <div className="px-4 py-3 border-b border-border">
            <h4 className="text-sm font-medium">超参数对比</h4>
          </div>
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-[140px] whitespace-nowrap">参数</TableHead>
                <TableHead className="whitespace-nowrap text-right">{versionA.version}</TableHead>
                <TableHead className="whitespace-nowrap text-right">{versionB.version}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow className="border-border">
                <TableCell className="font-medium text-sm">学习率</TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionA.hyperparams.learningRate}
                </TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionB.hyperparams.learningRate}
                </TableCell>
              </TableRow>
              <TableRow className="border-border">
                <TableCell className="font-medium text-sm">Batch Size</TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionA.hyperparams.batchSize}
                </TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionB.hyperparams.batchSize}
                </TableCell>
              </TableRow>
              <TableRow className="border-border">
                <TableCell className="font-medium text-sm">Epochs</TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionA.hyperparams.epochs}
                </TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionB.hyperparams.epochs}
                </TableCell>
              </TableRow>
              <TableRow className="border-border">
                <TableCell className="font-medium text-sm">优化器</TableCell>
                <TableCell className="text-right text-sm">
                  {versionA.hyperparams.optimizer.toUpperCase()}
                </TableCell>
                <TableCell className="text-right text-sm">
                  {versionB.hyperparams.optimizer.toUpperCase()}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>

        {/* 训练环境对比 */}
        <div className="rounded-lg border border-border overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h4 className="text-sm font-medium">训练环境对比</h4>
          </div>
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-[140px] whitespace-nowrap">配置</TableHead>
                <TableHead className="whitespace-nowrap text-right">{versionA.version}</TableHead>
                <TableHead className="whitespace-nowrap text-right">{versionB.version}</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow className="border-border">
                <TableCell className="font-medium text-sm">GPU 型号</TableCell>
                <TableCell className="text-right text-sm">
                  {versionA.trainingEnv.gpuType}
                </TableCell>
                <TableCell className="text-right text-sm">
                  {versionB.trainingEnv.gpuType}
                </TableCell>
              </TableRow>
              <TableRow className="border-border">
                <TableCell className="font-medium text-sm">GPU 数量</TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionA.trainingEnv.gpuCount} 卡
                </TableCell>
                <TableCell className="text-right tabular-nums text-sm">
                  {versionB.trainingEnv.gpuCount} 卡
                </TableCell>
              </TableRow>
              <TableRow className="border-border">
                <TableCell className="font-medium text-sm">内存</TableCell>
                <TableCell className="text-right text-sm">
                  {versionA.trainingEnv.memoryGB} GB
                </TableCell>
                <TableCell className="text-right text-sm">
                  {versionB.trainingEnv.memoryGB} GB
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </SheetContent>
    </Sheet>
  );
}
