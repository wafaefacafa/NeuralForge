import { useState, useCallback, useEffect } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger, scopedStorage } from '@lark-apaas/client-toolkit-lite';
import { User, Key, Bell, Shield } from 'lucide-react';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

import ProfileSection from './ProfileSection';
import ApiKeysSection from './ApiKeysSection';
import NotificationSection from './NotificationSection';
import SecuritySection from './SecuritySection';

import { MOCK_USER_SETTINGS } from '@/data/userSettings';
import type { IUserSettings, IApiKey, INotificationSettings } from '@/types/settings';

const STORAGE_KEY = '__neuralforge_userSettings';

function loadSettings(): IUserSettings {
  try {
    const stored = scopedStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored) as IUserSettings;
      return parsed;
    }
  } catch (err) {
    logger.warn('Failed to load user settings from storage, using defaults');
  }
  return MOCK_USER_SETTINGS;
}

function saveSettings(settings: IUserSettings) {
  try {
    scopedStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (err) {
    logger.error('Failed to save user settings:', String(err));
  }
}

const TAB_ITEMS = [
  { value: 'profile', label: '个人信息', icon: User },
  { value: 'api-keys', label: 'API 密钥', icon: Key },
  { value: 'notifications', label: '通知设置', icon: Bell },
  { value: 'security', label: '安全设置', icon: Shield },
] as const;

export default function SettingsPage() {
  const [settings, setSettings] = useState<IUserSettings>(() => loadSettings());
  const [activeTab, setActiveTab] = useState('profile');

  // 持久化
  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  // 更新个人信息
  const handleProfileSave = useCallback(
    (profile: IUserSettings['profile']) => {
      setSettings((prev) => ({ ...prev, profile }));
      toast.success('个人信息已保存');
      logger.info('Profile updated');
    },
    [],
  );

  // 更新 API 密钥
  const handleApiKeysUpdate = useCallback(
    (keys: IApiKey[]) => {
      setSettings((prev) => ({ ...prev, apiKeys: keys }));
    },
    [],
  );

  // 更新通知设置
  const handleNotificationsSave = useCallback(
    (notifications: INotificationSettings) => {
      setSettings((prev) => ({ ...prev, notifications }));
    },
    [],
  );

  // 更新双因素认证
  const handleTwoFactorChange = useCallback(
    (enabled: boolean) => {
      setSettings((prev) => ({
        ...prev,
        security: { ...prev.security, twoFactorEnabled: enabled },
      }));
    },
    [],
  );

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      >
        <h1 className="text-2xl font-bold tracking-tight text-foreground">个人设置</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          管理您的账户信息、API 密钥、通知偏好和安全设置
        </p>
      </motion.div>

      {/* Tab 导航 */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="h-auto w-full justify-start gap-1 rounded-xl bg-muted/40 p-1 overflow-x-auto">
          {TAB_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <TabsTrigger
                key={item.value}
                value={item.value}
                className="flex items-center gap-2 rounded-lg px-4 py-2 text-sm data-[state=active]:bg-card data-[state=active]:shadow-sm shrink-0"
              >
                <Icon className="size-4" />
                <span className="hidden sm:inline">{item.label}</span>
              </TabsTrigger>
            );
          })}
        </TabsList>

        {/* 个人信息 */}
        <TabsContent value="profile" className="mt-6">
          <ProfileSection
            profile={settings.profile}
            onSave={handleProfileSave}
          />
        </TabsContent>

        {/* API 密钥 */}
        <TabsContent value="api-keys" className="mt-6">
          <ApiKeysSection
            apiKeys={settings.apiKeys}
            onUpdateKeys={handleApiKeysUpdate}
          />
        </TabsContent>

        {/* 通知设置 */}
        <TabsContent value="notifications" className="mt-6">
          <NotificationSection
            settings={settings.notifications}
            onSave={handleNotificationsSave}
          />
        </TabsContent>

        {/* 安全设置 */}
        <TabsContent value="security" className="mt-6">
          <SecuritySection
            twoFactorEnabled={settings.security.twoFactorEnabled}
            onTwoFactorChange={handleTwoFactorChange}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
