import { useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import { ArrowLeft, Rocket } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

import DeployConfigForm from './DeployConfigForm';
import DeployConfigPreview from './DeployConfigPreview';

import { MOCK_MODEL_VERSIONS } from '@/data/modelVersions';
import { MOCK_DEPLOY_ENVIRONMENTS, MOCK_INSTANCE_SPECS } from '@/data/deployOptions';
import type { IDeployConfig } from '@/types/deploy';

export default function DeployConfigPage() {
  const { versionId } = useParams<{ versionId: string }>();
  const navigate = useNavigate();

  const version = MOCK_MODEL_VERSIONS.find((v) => v.id === versionId);

  const [config, setConfig] = useState<Partial<IDeployConfig>>({
    projectId: version?.projectId ?? '',
    modelVersionId: versionId ?? '',
    environment: MOCK_DEPLOY_ENVIRONMENTS[0]?.id ?? '',
    instanceSpecId: MOCK_INSTANCE_SPECS[0]?.id ?? '',
    instanceCount: 1,
    autoScale: {
      enabled: false,
      minInstances: 1,
      maxInstances: 4,
      cpuThreshold: 70,
      scaleDownDelay: 300,
    },
    trafficAllocations: [],
    description: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const handleConfigChange = useCallback((partial: Partial<IDeployConfig>) => {
    setConfig((prev) => ({ ...prev, ...partial }));
  }, []);

  const handleDeploy = useCallback(async () => {
    if (!config.environment) {
      toast.error('请选择部署环境');
      return;
    }
    if (!config.instanceSpecId) {
      toast.error('请选择实例规格');
      return;
    }

    setSubmitting(true);
    try {
      await new Promise((r) => setTimeout(r, 1500));
      toast.success('部署任务已创建，正在启动实例...');
      logger.info('Deploy config submitted:', config);
      navigate('/deploy/instances');
    } catch (err) {
      logger.error('Deploy failed:', String(err));
      toast.error('部署失败，请重试');
    } finally {
      setSubmitting(false);
    }
  }, [config, navigate]);

  if (!version) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <Rocket className="size-16 text-muted-foreground/30 mb-4" />
        <h2 className="text-lg font-semibold text-foreground">模型版本不存在</h2>
        <p className="mt-1 text-sm text-muted-foreground">请从模型版本管理页选择有效版本</p>
        <Button variant="outline" className="mt-6" onClick={() => navigate('/models')}>
          <ArrowLeft className="mr-2 size-4" />
          返回模型列表
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 顶部标题栏 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-3 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="shrink-0"
            onClick={() => navigate('/models')}
            aria-label="返回模型列表"
          >
            <ArrowLeft className="size-4" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-xl font-bold tracking-tight text-foreground truncate">
              部署配置
            </h1>
            <p className="text-sm text-muted-foreground truncate">
              {version.modelName} · {version.version}
            </p>
          </div>
        </div>

        <Button
          size="lg"
          className="gap-2 shrink-0"
          onClick={handleDeploy}
          disabled={submitting}
        >
          <Rocket className="size-4" />
          {submitting ? '部署中...' : '开始部署'}
        </Button>
      </motion.div>

      {/* 模型版本摘要卡片 */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.08 }}
      >
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold">模型版本信息</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-lg bg-muted/40 p-3">
                <p className="text-[11px] text-muted-foreground uppercase tracking-wider">版本号</p>
                <p className="mt-0.5 text-sm font-semibold tabular-nums">{version.version}</p>
              </div>
              <div className="rounded-lg bg-muted/40 p-3">
                <p className="text-[11px] text-muted-foreground uppercase tracking-wider">框架</p>
                <p className="mt-0.5 text-sm font-semibold">{version.framework}</p>
              </div>
              <div className="rounded-lg bg-muted/40 p-3">
                <p className="text-[11px] text-muted-foreground uppercase tracking-wider">Accuracy</p>
                <p className="mt-0.5 text-sm font-semibold tabular-nums text-success">
                  {(version.accuracy * 100).toFixed(1)}%
                </p>
              </div>
              <div className="rounded-lg bg-muted/40 p-3">
                <p className="text-[11px] text-muted-foreground uppercase tracking-wider">模型大小</p>
                <p className="mt-0.5 text-sm font-semibold tabular-nums">{version.sizeMB} MB</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* 主内容区：左右分栏 */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* 左侧：配置表单 */}
        <motion.div
          initial={{ opacity: 0, x: -16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.12, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-2"
        >
          <DeployConfigForm modelVersionId={versionId ?? ''} modelName={version?.modelName} projectId={version?.projectId} />
        </motion.div>

        {/* 右侧：配置预览 */}
        <motion.div
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.16, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-1"
        >
          <div className="sticky top-20">
            <DeployConfigPreview config={config} />
          </div>
        </motion.div>
      </div>
    </div>
  );
}
