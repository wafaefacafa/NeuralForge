import { useState, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import { ArrowLeft, Play, Save, RotateCcw } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

import { MOCK_PROJECTS, GPU_OPTIONS } from '@/data/projects';
import { NETWORK_TEMPLATES, OPTIMIZER_OPTIONS, LR_SCHEDULER_OPTIONS } from '@/data/trainingOptions';
import type { IHyperParams, INetworkTemplate, ITrainingDatasetSplit } from '@/types/training';
import { CHART_COLORS } from '@/lib/chart-colors';

// ---------- 默认超参数 ----------
const DEFAULT_HYPER_PARAMS: IHyperParams = {
  learningRate: 0.001,
  batchSize: 32,
  epochs: 50,
  optimizer: 'adam',
  weightDecay: 0.0001,
  learningRateScheduler: 'cosine',
  earlyStoppingPatience: 10,
  dataAugmentation: true,
};

// ---------- 模拟数据集列表 ----------
const MOCK_DATASETS = [
  { id: 'ds1', name: 'ImageNet-subset', sampleCount: 50000, category: 'image' },
  { id: 'ds2', name: 'COCO-2017', sampleCount: 118000, category: 'image' },
  { id: 'ds3', name: 'WikiText-103', sampleCount: 103000, category: 'text' },
];

export default function TrainingConfigPage() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();

  // 查找项目
  const project = useMemo(
    () => MOCK_PROJECTS.find((p) => p.id === projectId),
    [projectId],
  );

  // 超参数
  const [hyperParams, setHyperParams] = useState<IHyperParams>(DEFAULT_HYPER_PARAMS);

  // 网络模板
  const [selectedTemplate, setSelectedTemplate] = useState<INetworkTemplate | null>(null);

  // 数据集划分
  const [datasetSplit, setDatasetSplit] = useState<ITrainingDatasetSplit>({
    datasetId: '',
    datasetName: '',
    trainRatio: 80,
    valRatio: 15,
    testRatio: 5,
  });

  // 高级配置折叠
  const [advancedOpen, setAdvancedOpen] = useState(false);

  // 提交状态
  const [submitting, setSubmitting] = useState(false);

  // ---------- 超参数更新 ----------
  const updateHyperParam = useCallback(
    <K extends keyof IHyperParams>(key: K, value: IHyperParams[K]) => {
      setHyperParams((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  // ---------- 数据集选择 ----------
  const handleDatasetChange = useCallback(
    (datasetId: string) => {
      const ds = MOCK_DATASETS.find((d) => d.id === datasetId);
      setDatasetSplit((prev) => ({
        ...prev,
        datasetId,
        datasetName: ds?.name ?? '',
      }));
    },
    [],
  );

  // ---------- 训练/验证比例滑块联动 ----------
  const handleTrainRatioChange = useCallback((value: number[]) => {
    const train = value[0];
    const remaining = 100 - train;
    const val = Math.round(remaining * 0.75);
    const test = remaining - val;
    setDatasetSplit({ ...datasetSplit, trainRatio: train, valRatio: val, testRatio: test });
  }, [datasetSplit]);

  // ---------- 重置 ----------
  const handleReset = useCallback(() => {
    setHyperParams(DEFAULT_HYPER_PARAMS);
    setSelectedTemplate(null);
    setDatasetSplit({ datasetId: '', datasetName: '', trainRatio: 80, valRatio: 15, testRatio: 5 });
    setAdvancedOpen(false);
    toast.info('配置已重置');
  }, []);

  // ---------- 提交 ----------
  const handleSubmit = useCallback(async () => {
    if (!selectedTemplate) {
      toast.error('请选择网络结构');
      return;
    }
    if (!datasetSplit.datasetId) {
      toast.error('请选择训练数据集');
      return;
    }

    setSubmitting(true);
    try {
      await new Promise((r) => setTimeout(r, 1200));
      toast.success('训练任务已创建！');
      logger.info('Training job created', {
        projectId,
        hyperParams,
        template: selectedTemplate.name,
        dataset: datasetSplit.datasetName,
      });
      // 跳转到训练监控页
      navigate(`/training/monitor/job_${Date.now()}`);
    } catch (err) {
      logger.error('Create training job failed:', String(err));
      toast.error('创建失败，请重试');
    } finally {
      setSubmitting(false);
    }
  }, [selectedTemplate, datasetSplit, hyperParams, projectId, navigate]);

  // ---------- 费用估算 ----------
  const gpuInfo = GPU_OPTIONS.find(
    (g) => g.value === (project?.hardware.gpuType ?? 'A100'),
  );
  const estimatedHours = Math.ceil(
    (hyperParams.epochs * (MOCK_DATASETS.find((d) => d.id === datasetSplit.datasetId)?.sampleCount ?? 50000)) /
      (hyperParams.batchSize * 3600),
  );
  const gpuPrice = gpuInfo ? (gpuInfo.value === 'A100' ? 3.06 : gpuInfo.value === 'V100' ? 2.48 : 0.95) : 3.06;
  const estimatedCost = (estimatedHours * gpuPrice * (project?.hardware.gpuCount ?? 1)).toFixed(2);

  // ---------- 项目不存在 ----------
  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="text-6xl mb-4">🔍</div>
        <h2 className="text-lg font-semibold text-foreground mb-2">项目未找到</h2>
        <p className="text-sm text-muted-foreground mb-6">
          项目 ID: {projectId} 不存在或已被删除
        </p>
        <Button variant="outline" onClick={() => navigate('/projects')}>
          <ArrowLeft className="mr-2 size-4" />
          返回项目列表
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 顶部标题栏 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="flex items-center gap-3 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="shrink-0"
            onClick={() => navigate('/projects')}
            aria-label="返回项目列表"
          >
            <ArrowLeft className="size-4" />
          </Button>
          <div className="min-w-0">
            <h1 className="text-xl font-bold tracking-tight text-foreground truncate">
              训练配置
            </h1>
            <p className="text-sm text-muted-foreground truncate">
              项目：{project.name}
              <Badge variant="secondary" className="ml-2 text-[10px] align-middle">
                {project.framework}
              </Badge>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button variant="outline" size="sm" onClick={handleReset} className="gap-1.5">
            <RotateCcw className="size-3.5" />
            重置
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5">
            <Save className="size-3.5" />
            保存草稿
          </Button>
          <Button
            size="sm"
            onClick={handleSubmit}
            disabled={submitting}
            className="gap-1.5 bg-primary hover:bg-primary/90"
          >
            <Play className="size-3.5" />
            {submitting ? '创建中...' : '开始训练'}
          </Button>
        </div>
      </motion.div>

      {/* 主体：左右分栏 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 左栏：配置表单 (占 2/3) */}
        <div className="lg:col-span-2 space-y-6">
          {/* 超参数配置 */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.05 }}
          >
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-base">超参数配置</CardTitle>
                <CardDescription>设置训练超参数，影响模型收敛速度和最终性能</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {/* 学习率 */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="lr" className="text-sm font-medium">
                      学习率 (Learning Rate)
                    </Label>
                    <span className="text-xs font-mono tabular-nums text-muted-foreground">
                      {hyperParams.learningRate}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Slider
                      id="lr"
                      min={0.00001}
                      max={0.1}
                      step={0.0001}
                      value={[hyperParams.learningRate]}
                      onValueChange={(v) => updateHyperParam('learningRate', v[0])}
                      className="flex-1"
                    />
                    <Input
                      type="number"
                      value={hyperParams.learningRate}
                      onChange={(e) => {
                        const v = parseFloat(e.target.value);
                        if (!isNaN(v) && v > 0) updateHyperParam('learningRate', v);
                      }}
                      className="w-24 h-8 text-xs font-mono bg-muted/50"
                      step={0.0001}
                      min={0.00001}
                    />
                  </div>
                </div>

                {/* Batch Size */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="batch" className="text-sm font-medium">
                      Batch Size
                    </Label>
                    <span className="text-xs font-mono tabular-nums text-muted-foreground">
                      {hyperParams.batchSize}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Slider
                      id="batch"
                      min={1}
                      max={256}
                      step={1}
                      value={[hyperParams.batchSize]}
                      onValueChange={(v) => updateHyperParam('batchSize', v[0])}
                      className="flex-1"
                    />
                    <Input
                      type="number"
                      value={hyperParams.batchSize}
                      onChange={(e) => {
                        const v = parseInt(e.target.value, 10);
                        if (!isNaN(v) && v > 0) updateHyperParam('batchSize', v);
                      }}
                      className="w-20 h-8 text-xs font-mono bg-muted/50"
                      min={1}
                    />
                  </div>
                </div>

                {/* Epochs */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="epochs" className="text-sm font-medium">
                      Epochs
                    </Label>
                    <span className="text-xs font-mono tabular-nums text-muted-foreground">
                      {hyperParams.epochs}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Slider
                      id="epochs"
                      min={1}
                      max={500}
                      step={1}
                      value={[hyperParams.epochs]}
                      onValueChange={(v) => updateHyperParam('epochs', v[0])}
                      className="flex-1"
                    />
                    <Input
                      type="number"
                      value={hyperParams.epochs}
                      onChange={(e) => {
                        const v = parseInt(e.target.value, 10);
                        if (!isNaN(v) && v > 0) updateHyperParam('epochs', v);
                      }}
                      className="w-20 h-8 text-xs font-mono bg-muted/50"
                      min={1}
                    />
                  </div>
                </div>

                <Separator />

                {/* 优化器 + 权重衰减 */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">优化器 (Optimizer)</Label>
                    <Select
                      value={hyperParams.optimizer}
                      onValueChange={(v) => updateHyperParam('optimizer', v as IHyperParams['optimizer'])}
                    >
                      <SelectTrigger className="bg-muted/50">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {OPTIMIZER_OPTIONS.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>
                            <div className="flex flex-col gap-0.5">
                              <span className="text-sm font-medium">{opt.label}</span>
                              <span className="text-[11px] text-muted-foreground">{opt.description}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="wd" className="text-sm font-medium">
                      权重衰减 (Weight Decay)
                    </Label>
                    <Input
                      id="wd"
                      type="number"
                      value={hyperParams.weightDecay}
                      onChange={(e) => {
                        const v = parseFloat(e.target.value);
                        if (!isNaN(v) && v >= 0) updateHyperParam('weightDecay', v);
                      }}
                      className="bg-muted/50 font-mono text-xs"
                      step={0.0001}
                      min={0}
                    />
                  </div>
                </div>

                {/* 高级配置折叠面板 */}
                <Collapsible open={advancedOpen} onOpenChange={setAdvancedOpen}>
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-between text-muted-foreground hover:text-foreground"
                    >
                      <span className="text-xs font-medium">高级配置</span>
                      <span className="text-[10px]">
                        {advancedOpen ? '收起 ▲' : '展开 ▼'}
                      </span>
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-4 pt-3">
                    {/* 学习率调度器 */}
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">学习率调度器 (LR Scheduler)</Label>
                      <Select
                        value={hyperParams.learningRateScheduler}
                        onValueChange={(v) =>
                          updateHyperParam('learningRateScheduler', v as IHyperParams['learningRateScheduler'])
                        }
                      >
                        <SelectTrigger className="bg-muted/50">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {LR_SCHEDULER_OPTIONS.map((opt) => (
                            <SelectItem key={opt.value} value={opt.value}>
                              <div className="flex flex-col gap-0.5">
                                <span className="text-sm font-medium">{opt.label}</span>
                                <span className="text-[11px] text-muted-foreground">{opt.description}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* 早停策略 */}
                    <div className="space-y-2">
                      <Label htmlFor="early-stop" className="text-sm font-medium">
                        早停耐心值 (Early Stopping Patience)
                      </Label>
                      <div className="flex items-center gap-3">
                        <Slider
                          id="early-stop"
                          min={1}
                          max={50}
                          step={1}
                          value={[hyperParams.earlyStoppingPatience]}
                          onValueChange={(v) => updateHyperParam('earlyStoppingPatience', v[0])}
                          className="flex-1"
                        />
                        <span className="w-10 text-right text-xs font-mono tabular-nums text-muted-foreground">
                          {hyperParams.earlyStoppingPatience}
                        </span>
                      </div>
                      <p className="text-[11px] text-muted-foreground">
                        验证集指标连续 {hyperParams.earlyStoppingPatience} 个 epoch 未提升时停止训练
                      </p>
                    </div>

                    {/* 数据增强 */}
                    <div className="flex items-center justify-between rounded-lg bg-muted/30 px-3 py-2.5">
                      <div className="space-y-0.5">
                        <p className="text-sm font-medium text-foreground">数据增强 (Data Augmentation)</p>
                        <p className="text-xs text-muted-foreground">
                          随机翻转、旋转、裁剪等增强训练数据
                        </p>
                      </div>
                      <Switch
                        checked={hyperParams.dataAugmentation}
                        onCheckedChange={(v) => updateHyperParam('dataAugmentation', v)}
                      />
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </CardContent>
            </Card>
          </motion.div>

          {/* 网络结构选择 */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.1 }}
          >
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-base">网络结构</CardTitle>
                <CardDescription>选择预置网络模板或使用自定义结构</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {NETWORK_TEMPLATES.map((template) => {
                    const isSelected = selectedTemplate?.id === template.id;
                    return (
                      <button
                        key={template.id}
                        type="button"
                        onClick={() => setSelectedTemplate(template)}
                        className={`relative flex flex-col gap-2 rounded-xl border p-4 text-left transition-all duration-200 ${
                          isSelected
                            ? 'border-primary bg-primary/5 ring-1 ring-primary/30 shadow-sm'
                            : 'border-border/40 bg-card/40 hover:border-primary/30 hover:bg-muted/30'
                        }`}
                      >
                        {/* 选中标记 */}
                        {isSelected && (
                          <div className="absolute right-3 top-3 flex size-5 items-center justify-center rounded-full bg-primary">
                            <svg
                              className="size-3 text-primary-foreground"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                              strokeWidth={3}
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                            </svg>
                          </div>
                        )}

                        {/* 图标 + 名称 */}
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`flex size-9 items-center justify-center rounded-lg text-lg ${
                              isSelected ? 'bg-primary/15' : 'bg-muted'
                            }`}
                          >
                            {template.icon}
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-foreground truncate">
                              {template.name}
                            </p>
                            <p className="text-[11px] text-muted-foreground">
                              {template.paramsCount} 参数
                            </p>
                          </div>
                        </div>

                        {/* 描述 */}
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {template.description}
                        </p>

                        {/* 框架标签 */}
                        <Badge variant="outline" className="w-fit text-[10px]">
                          {template.framework}
                        </Badge>
                      </button>
                    );
                  })}

                  {/* 自定义选项 */}
                  <button
                    type="button"
                    onClick={() => toast.info('自定义网络结构功能即将开放')}
                    className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border/60 bg-card/30 p-4 text-center transition-all hover:border-primary/40 hover:bg-muted/20"
                  >
                    <div className="flex size-9 items-center justify-center rounded-lg bg-muted text-xl">
                      🛠️
                    </div>
                    <p className="text-sm font-medium text-muted-foreground">自定义结构</p>
                    <p className="text-[11px] text-muted-foreground/60">即将开放</p>
                  </button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* 数据集划分 */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, delay: 0.15 }}
          >
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-base">数据集划分</CardTitle>
                <CardDescription>选择训练数据集并配置训练/验证/测试集比例</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {/* 数据集选择 */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">
                    训练数据集 <span className="text-destructive">*</span>
                  </Label>
                  <Select
                    value={datasetSplit.datasetId}
                    onValueChange={handleDatasetChange}
                  >
                    <SelectTrigger className="bg-muted/50">
                      <SelectValue placeholder="选择数据集" />
                    </SelectTrigger>
                    <SelectContent>
                      {MOCK_DATASETS.map((ds) => (
                        <SelectItem key={ds.id} value={ds.id}>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">{ds.name}</span>
                            <span className="text-[11px] text-muted-foreground">
                              {ds.sampleCount.toLocaleString()} 样本
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* 比例滑块 */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">训练集比例</Label>
                    <span className="text-xs font-mono tabular-nums text-muted-foreground">
                      {datasetSplit.trainRatio}%
                    </span>
                  </div>
                  <Slider
                    min={50}
                    max={95}
                    step={5}
                    value={[datasetSplit.trainRatio]}
                    onValueChange={handleTrainRatioChange}
                  />
                </div>

                {/* 比例可视化 */}
                <div className="space-y-2">
                  <div className="flex h-6 w-full overflow-hidden rounded-md">
                    <div
                      className="flex items-center justify-center bg-primary/70 text-[10px] font-semibold text-primary-foreground transition-all"
                      style={{ width: `${datasetSplit.trainRatio}%` }}
                    >
                      训练 {datasetSplit.trainRatio}%
                    </div>
                    <div
                      className="flex items-center justify-center bg-accent/70 text-[10px] font-semibold text-accent-foreground transition-all"
                      style={{ width: `${datasetSplit.valRatio}%` }}
                    >
                      验证 {datasetSplit.valRatio}%
                    </div>
                    <div
                      className="flex items-center justify-center bg-muted-foreground/40 text-[10px] font-semibold text-foreground transition-all"
                      style={{ width: `${datasetSplit.testRatio}%` }}
                    >
                      测试 {datasetSplit.testRatio}%
                    </div>
                  </div>

                  {/* 图例 */}
                  <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
                    <div className="flex items-center gap-1.5">
                      <div className="size-2.5 rounded-sm bg-primary/70" />
                      训练集
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="size-2.5 rounded-sm bg-accent/70" />
                      验证集
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="size-2.5 rounded-sm bg-muted-foreground/40" />
                      测试集
                    </div>
                  </div>
                </div>

                {/* 样本数估算 */}
                {datasetSplit.datasetId && (
                  <div className="rounded-lg bg-muted/30 p-3">
                    <p className="text-xs text-muted-foreground">
                      预计样本分配：
                      <span className="ml-1 font-semibold text-foreground tabular-nums">
                        {Math.round(
                          (MOCK_DATASETS.find((d) => d.id === datasetSplit.datasetId)?.sampleCount ?? 0) *
                            (datasetSplit.trainRatio / 100),
                        ).toLocaleString()}
                      </span>
                      {' '}训练 /
                      <span className="ml-1 font-semibold text-foreground tabular-nums">
                        {Math.round(
                          (MOCK_DATASETS.find((d) => d.id === datasetSplit.datasetId)?.sampleCount ?? 0) *
                            (datasetSplit.valRatio / 100),
                        ).toLocaleString()}
                      </span>
                      {' '}验证 /
                      <span className="ml-1 font-semibold text-foreground tabular-nums">
                        {Math.round(
                          (MOCK_DATASETS.find((d) => d.id === datasetSplit.datasetId)?.sampleCount ?? 0) *
                            (datasetSplit.testRatio / 100),
                        ).toLocaleString()}
                      </span>
                      {' '}测试
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* 右栏：配置预览 (占 1/3) */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="space-y-5"
        >
          {/* 标题 */}
          <div className="flex items-center gap-2">
            <div className="flex size-8 items-center justify-center rounded-lg bg-primary/10">
              <svg className="size-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-foreground">配置预览</h3>
              <p className="text-xs text-muted-foreground">实时预览训练配置</p>
            </div>
          </div>

          {/* 项目信息 */}
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">项目信息</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">项目名称</span>
                <span className="text-xs font-medium text-foreground truncate max-w-[160px]">
                  {project.name}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">框架</span>
                <Badge variant="secondary" className="text-[10px]">
                  {project.framework}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">GPU</span>
                <span className="text-xs font-medium text-foreground">
                  {project.hardware.gpuType} × {project.hardware.gpuCount}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">内存</span>
                <span className="text-xs font-medium text-foreground">
                  {project.hardware.memoryGB} GB
                </span>
              </div>
            </CardContent>
          </Card>

          {/* 超参数摘要 */}
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">超参数摘要</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">学习率</span>
                <span className="text-xs font-mono font-medium text-foreground">
                  {hyperParams.learningRate}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Batch Size</span>
                <span className="text-xs font-mono font-medium text-foreground">
                  {hyperParams.batchSize}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Epochs</span>
                <span className="text-xs font-mono font-medium text-foreground">
                  {hyperParams.epochs}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">优化器</span>
                <span className="text-xs font-medium text-foreground">
                  {OPTIMIZER_OPTIONS.find((o) => o.value === hyperParams.optimizer)?.label ?? hyperParams.optimizer}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">权重衰减</span>
                <span className="text-xs font-mono font-medium text-foreground">
                  {hyperParams.weightDecay}
                </span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">LR 调度器</span>
                <span className="text-xs font-medium text-foreground">
                  {LR_SCHEDULER_OPTIONS.find((o) => o.value === hyperParams.learningRateScheduler)?.label ?? '-'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">早停耐心</span>
                <span className="text-xs font-mono font-medium text-foreground">
                  {hyperParams.earlyStoppingPatience}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">数据增强</span>
                <Badge variant={hyperParams.dataAugmentation ? 'default' : 'secondary'} className="text-[10px]">
                  {hyperParams.dataAugmentation ? '开启' : '关闭'}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* 网络结构摘要 */}
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">网络结构</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedTemplate ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2.5">
                    <div className="flex size-8 items-center justify-center rounded-lg bg-primary/15 text-base">
                      {selectedTemplate.icon}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-foreground truncate">
                        {selectedTemplate.name}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {selectedTemplate.paramsCount} 参数
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">{selectedTemplate.description}</p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="text-2xl mb-2 opacity-40">🧠</div>
                  <p className="text-xs text-muted-foreground">尚未选择网络结构</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* 数据集摘要 */}
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">数据集</CardTitle>
            </CardHeader>
            <CardContent>
              {datasetSplit.datasetId ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">数据集</span>
                    <span className="text-xs font-medium text-foreground">
                      {datasetSplit.datasetName}
                    </span>
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">训练集</span>
                      <span className="font-mono tabular-nums text-foreground">{datasetSplit.trainRatio}%</span>
                    </div>
                    <Progress value={datasetSplit.trainRatio} className="h-1.5" />
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">验证集</span>
                      <span className="font-mono tabular-nums text-foreground">{datasetSplit.valRatio}%</span>
                    </div>
                    <Progress value={datasetSplit.valRatio} className="h-1.5 [&>div]:bg-accent" />
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">测试集</span>
                      <span className="font-mono tabular-nums text-foreground">{datasetSplit.testRatio}%</span>
                    </div>
                    <Progress value={datasetSplit.testRatio} className="h-1.5 [&>div]:bg-muted-foreground/40" />
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="text-2xl mb-2 opacity-40">📊</div>
                  <p className="text-xs text-muted-foreground">尚未选择数据集</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* 费用估算 */}
          <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">费用估算</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">GPU 规格</span>
                <span className="text-xs font-medium text-foreground">
                  {gpuInfo?.label ?? '-'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">GPU 数量</span>
                <span className="text-xs font-medium text-foreground">
                  {project.hardware.gpuCount} 卡
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">预计时长</span>
                <span className="text-xs font-medium text-foreground">
                  ~{estimatedHours} 小时
                </span>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">GPU 单价</span>
                <span className="text-xs font-mono font-medium text-foreground">
                  ${gpuPrice}/小时/卡
                </span>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-primary/5 p-3">
                <span className="text-xs font-semibold text-foreground">预估总费用</span>
                <span className="text-sm font-bold tabular-nums text-primary">
                  ${estimatedCost}
                </span>
              </div>
              <p className="text-[10px] text-muted-foreground/60">
                * 费用为预估值，实际费用以训练完成后结算为准
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
