import { useState, useCallback, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import { BrainCircuit, Mail, Lock, Eye, EyeOff, Github, Chrome } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import { Image } from '@/components/ui/image';

// 登录页背景图（AI 生成的 Hero 图）
const LOGIN_BG_IMAGE =
  '/spark/app/app_178vmey7j1j/runtime/api/v1/storage/object/bucket_aadkhskrgcadw_static/static%2Faadkhsfz7pgdw_ve_miaoda';

export default function LoginPage() {
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleLogin = useCallback(
    async (e: FormEvent) => {
      e.preventDefault();

      const trimmedEmail = email.trim();
      if (!trimmedEmail) {
        toast.error('请输入邮箱地址');
        return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
        toast.error('请输入有效的邮箱地址');
        return;
      }
      if (!password) {
        toast.error('请输入密码');
        return;
      }
      if (password.length < 6) {
        toast.error('密码长度至少 6 位');
        return;
      }

      setSubmitting(true);
      try {
        // 模拟登录请求
        await new Promise((r) => setTimeout(r, 1200));

        if (rememberMe) {
          localStorage.setItem('__neuralforge_remember_email', trimmedEmail);
        } else {
          localStorage.removeItem('__neuralforge_remember_email');
        }

        toast.success('登录成功，欢迎回来！');
        logger.info('User logged in:', trimmedEmail);
        navigate('/');
      } catch (err) {
        logger.error('Login failed:', String(err));
        toast.error('登录失败，请检查邮箱和密码');
      } finally {
        setSubmitting(false);
      }
    },
    [email, password, rememberMe, navigate],
  );

  const handleSSOLogin = useCallback(
    async (provider: string) => {
      toast.info(`正在跳转至 ${provider} SSO 登录...`);
      logger.info('SSO login initiated:', provider);
      try {
        await new Promise((r) => setTimeout(r, 800));
        toast.success(`${provider} 登录成功`);
        navigate('/');
      } catch {
        toast.error('SSO 登录失败，请重试');
      }
    },
    [navigate],
  );

  return (
    <div className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-background">
      {/* 背景图层 */}
      <div className="absolute inset-0 z-0">
        <Image
          src={LOGIN_BG_IMAGE}
          alt="NeuralForge AI 神经网络可视化背景"
          className="h-full w-full object-cover opacity-25"
        />
        {/* 渐变遮罩 */}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background/90 to-background" />
        <div className="absolute inset-0 bg-gradient-to-tl from-primary/10 via-transparent to-accent/10" />
      </div>

      {/* 装饰性光晕 */}
      <div className="pointer-events-none absolute -left-32 top-1/4 z-0 size-96 rounded-full bg-primary/20 blur-[128px]" />
      <div className="pointer-events-none absolute -right-32 bottom-1/4 z-0 size-96 rounded-full bg-accent/15 blur-[128px]" />

      {/* 登录卡片 */}
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-[420px] px-4"
      >
        <div className="rounded-2xl border border-border/40 bg-card/70 backdrop-blur-xl shadow-2xl">
          <div className="px-8 pb-8 pt-10">
            {/* 品牌标识 */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="flex flex-col items-center gap-3 mb-8"
            >
              <div className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-lg shadow-primary/25">
                <BrainCircuit className="size-7 text-primary-foreground" />
              </div>
              <div className="text-center">
                <h1 className="text-2xl font-bold tracking-tight text-foreground">
                  NeuralForge
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  企业级 AI 模型训练与部署平台
                </p>
              </div>
            </motion.div>

            {/* 登录表单 */}
            <motion.form
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.35, duration: 0.5 }}
              onSubmit={handleLogin}
              className="space-y-5"
              noValidate
            >
              {/* 邮箱 */}
              <div className="space-y-2">
                <Label htmlFor="login-email" className="text-sm font-medium">
                  邮箱地址
                </Label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="login-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@company.com"
                    className="bg-muted/50 pl-10"
                    autoComplete="email"
                    autoFocus
                  />
                </div>
              </div>

              {/* 密码 */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="login-password" className="text-sm font-medium">
                    密码
                  </Label>
                  <button
                    type="button"
                    className="text-xs text-primary hover:text-primary/80 transition-colors"
                    onClick={() => toast.info('密码重置链接已发送至您的邮箱')}
                  >
                    忘记密码？
                  </button>
                </div>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="输入密码"
                    className="bg-muted/50 pl-10 pr-10"
                    autoComplete="current-password"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="!absolute right-1 top-1/2 z-20 h-7 w-7 -translate-y-1/2"
                    onClick={() => setShowPassword((v) => !v)}
                    aria-label={showPassword ? '隐藏密码' : '显示密码'}
                  >
                    {showPassword ? (
                      <EyeOff className="size-3.5" />
                    ) : (
                      <Eye className="size-3.5" />
                    )}
                  </Button>
                </div>
              </div>

              {/* 记住我 */}
              <div className="flex items-center gap-2">
                <Checkbox
                  id="remember-me"
                  checked={rememberMe}
                  onCheckedChange={(checked) => setRememberMe(!!checked)}
                  className="border-border/60"
                />
                <Label
                  htmlFor="remember-me"
                  className="text-sm text-muted-foreground cursor-pointer select-none"
                >
                  记住我
                </Label>
              </div>

              {/* 登录按钮 */}
              <Button
                type="submit"
                disabled={submitting}
                className="w-full h-11 text-sm font-semibold shadow-lg shadow-primary/20"
              >
                {submitting ? (
                  <span className="flex items-center gap-2">
                    <span className="size-4 animate-spin rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground" />
                    登录中...
                  </span>
                ) : (
                  '登录'
                )}
              </Button>
            </motion.form>

            {/* 分隔线 */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.4 }}
              className="relative my-6"
            >
              <Separator className="bg-border/40" />
              <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-xs text-muted-foreground">
                或
              </span>
            </motion.div>

            {/* SSO 登录 */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.55, duration: 0.4 }}
              className="space-y-3"
            >
              <p className="text-center text-xs text-muted-foreground">使用 SSO 快速登录</p>
              <div className="grid grid-cols-3 gap-3">
                <Button
                  type="button"
                  variant="outline"
                  className="h-11 border-border/40 bg-muted/30 hover:bg-muted/50 hover:border-primary/30 transition-all duration-200"
                  onClick={() => handleSSOLogin('Google')}
                >
                  <Chrome className="size-4" />
                  <span className="ml-2 text-xs font-medium">Google</span>
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="h-11 border-border/40 bg-muted/30 hover:bg-muted/50 hover:border-primary/30 transition-all duration-200"
                  onClick={() => handleSSOLogin('GitHub')}
                >
                  <Github className="size-4" />
                  <span className="ml-2 text-xs font-medium">GitHub</span>
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="h-11 border-border/40 bg-muted/30 hover:bg-muted/50 hover:border-primary/30 transition-all duration-200"
                  onClick={() => handleSSOLogin('Microsoft')}
                >
                  <svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M11.4 24H0V12.6h11.4V24zM24 24H12.6V12.6H24V24zM11.4 11.4H0V0h11.4v11.4zm12.6 0H12.6V0H24v11.4z" />
                  </svg>
                  <span className="ml-2 text-xs font-medium">Microsoft</span>
                </Button>
              </div>
            </motion.div>

            {/* 注册链接 */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.65, duration: 0.4 }}
              className="mt-8 text-center text-sm text-muted-foreground"
            >
              还没有账号？{' '}
              <button
                type="button"
                className="font-medium text-primary hover:text-primary/80 transition-colors"
                onClick={() => toast.info('注册功能即将开放，请联系管理员')}
              >
                注册账号
              </button>
            </motion.p>
          </div>

          {/* 底部版权 */}
          <div className="rounded-b-2xl border-t border-border/30 bg-muted/20 px-8 py-4">
            <p className="text-center text-[11px] text-muted-foreground/60">
              &copy; 2026 NeuralForge. All rights reserved.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
