import { memo } from 'react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CHART_COLORS } from '@/lib/chart-colors';
import type { IResourceUsage } from '@/types/dashboard';

interface ResourceUsageSectionProps {
  data: IResourceUsage[];
}

export default memo(function ResourceUsageSection({ data }: ResourceUsageSectionProps) {
  const option: EChartsOption = {
    tooltip: {
      trigger: 'item',
      backgroundColor: 'rgba(20, 24, 36, 0.95)',
      borderColor: '#374151',
      textStyle: { color: '#e5e7eb', fontSize: 13 },
      formatter: (params: { name: string; value: number; percent: number }) => {
        const item = data.find((d) => d.label === params.name);
        if (!item) return `${params.name}: ${params.value}%`;
        return `${item.label}<br/>已用: ${item.used}${item.unit} / 总量: ${item.total}${item.unit}<br/>使用率: ${params.value}%`;
      },
    },
    legend: {
      bottom: 0,
      textStyle: { color: '#9ca3af', fontSize: 12 },
      itemWidth: 10,
      itemHeight: 10,
      itemGap: 20,
    },
    series: [
      {
        type: 'pie',
        radius: ['55%', '78%'],
        center: ['50%', '43%'],
        avoidLabelOverlap: false,
        label: { show: false },
        emphasis: { label: { show: false } },
        itemStyle: {
          borderColor: 'hsl(222 30% 8%)',
          borderWidth: 3,
          borderRadius: 4,
        },
        data: data.map((item, idx) => ({
          name: item.label,
          value: item.used,
          itemStyle: {
            color: CHART_COLORS[idx % CHART_COLORS.length],
          },
        })),
      },
    ],
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-semibold">资源使用率</CardTitle>
      </CardHeader>
      <CardContent>
        <ReactECharts option={option} theme="ud" className="h-[300px]" />
        <div className="mt-3 grid grid-cols-2 gap-3">
          {data.map((item, idx) => (
            <div
              key={item.type}
              className="flex items-center gap-2 rounded-lg bg-muted/40 px-3 py-2"
            >
              <div
                className="size-2.5 shrink-0 rounded-full"
                style={{ backgroundColor: CHART_COLORS[idx % CHART_COLORS.length] }}
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <span className="text-xs text-muted-foreground">{item.label}</span>
                  <span className="text-xs font-semibold tabular-nums">
                    {item.used}
                    <span className="text-[10px] font-normal text-muted-foreground">
                      /{item.total}{item.unit}
                    </span>
                  </span>
                </div>
                <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(item.used / (item.total || 1) * 100, 100)}%`,
                      backgroundColor:
                        item.used / (item.total || 1) * 100 >= item.threshold
                          ? CHART_COLORS[2]
                          : CHART_COLORS[idx % CHART_COLORS.length],
                    }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
});
