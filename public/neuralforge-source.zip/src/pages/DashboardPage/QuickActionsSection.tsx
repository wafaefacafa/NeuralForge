import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Plus, Upload, Play, Rocket, ArrowRight } from 'lucide-react';

import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: typeof Plus;
  route: string;
  color: string;
  bgColor: string;
}

const QUICK_ACTIONS: QuickAction[] = [
  {
    id: 'new-project',
    title: '新建项目',
    description: '创建新的 AI 训练项目',
    icon: Plus,
    route: '/projects/new',
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  {
    id: 'upload-dataset',
    title: '上传数据集',
    description: '上传并管理训练数据',
    icon: Upload,
    route: '/datasets',
    color: 'text-chart-2',
    bgColor: 'bg-chart-2/10',
  },
  {
    id: 'start-training',
    title: '开始训练',
    description: '配置并启动训练任务',
    icon: Play,
    route: '/projects',
    color: 'text-chart-3',
    bgColor: 'bg-chart-3/10',
  },
  {
    id: 'deploy-model',
    title: '部署模型',
    description: '将模型部署到生产环境',
    icon: Rocket,
    route: '/models',
    color: 'text-chart-4',
    bgColor: 'bg-chart-4/10',
  },
];

export default function QuickActionsSection() {
  const navigate = useNavigate();

  return (
    <section className="w-full">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {QUICK_ACTIONS.map((action, i) => (
          <motion.div
            key={action.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
            whileHover={{ y: -4, transition: { duration: 0.2 } }}
          >
            <Card
              className="group cursor-pointer border-border/50 bg-card/60 backdrop-blur-sm transition-all duration-200 hover:border-primary/30 hover:bg-card/80 hover:shadow-md"
              onClick={() => navigate(action.route)}
            >
              <CardContent className="flex items-center gap-4 p-5">
                <div
                  className={`flex size-11 shrink-0 items-center justify-center rounded-xl ${action.bgColor}`}
                >
                  <action.icon className={`size-5 ${action.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-semibold text-foreground truncate">
                      {action.title}
                    </h3>
                    <ArrowRight className="size-4 shrink-0 text-muted-foreground opacity-0 transition-all duration-200 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:text-primary" />
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground line-clamp-1">
                    {action.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
