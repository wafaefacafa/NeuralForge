import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { CHART_COLORS } from '@/lib/chart-colors';
import type { ITrainingTrendPoint } from '@/types/dashboard';

interface TrainingTrendChartProps {
  data: ITrainingTrendPoint[];
}

export default function TrainingTrendChart({ data }: TrainingTrendChartProps) {
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(20, 24, 36, 0.95)',
      borderColor: '#374151',
      textStyle: { color: '#e5e7eb', fontSize: 12 },
      axisPointer: {
        type: 'cross',
        crossStyle: { color: '#6b7280' },
        label: {
          backgroundColor: '#374151',
          color: '#e5e7eb',
        },
      },
    },
    legend: {
      bottom: 0,
      textStyle: { color: '#9ca3af', fontSize: 12 },
      itemWidth: 12,
      itemHeight: 8,
      itemGap: 20,
      data: ['提交任务', '完成任务'],
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '20%',
      top: '8%',
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: data.map((d) => d.date),
      axisLine: { lineStyle: { color: '#374151' } },
      axisTick: { show: false },
      axisLabel: { color: '#9ca3af', fontSize: 11 },
    },
    yAxis: {
      type: 'value',
      name: '任务数',
      nameTextStyle: { color: '#9ca3af', fontSize: 11 },
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: '#1f2937', type: 'dashed' } },
      axisLabel: { color: '#9ca3af', fontSize: 11 },
    },
    series: [
      {
        name: '提交任务',
        type: 'line',
        data: data.map((d) => d.submitted),
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        lineStyle: { width: 2.5, color: CHART_COLORS[0] },
        itemStyle: { color: CHART_COLORS[0] },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(79, 70, 229, 0.25)' },
              { offset: 1, color: 'rgba(79, 70, 229, 0.02)' },
            ],
          },
        },
      },
      {
        name: '完成任务',
        type: 'line',
        data: data.map((d) => d.completed),
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        lineStyle: { width: 2.5, color: CHART_COLORS[1] },
        itemStyle: { color: CHART_COLORS[1] },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(6, 182, 212, 0.25)' },
              { offset: 1, color: 'rgba(6, 182, 212, 0.02)' },
            ],
          },
        },
      },
    ],
  };

  return (
    <ReactECharts
      option={option}
      theme="ud"
      className="h-[300px] w-full"
      notMerge
      lazyUpdate
    />
  );
}
