import { memo } from 'react';
import { motion } from 'framer-motion';
import {
  FolderOpen,
  CheckCircle2,
  Rocket,
  Upload,
  UserPlus,
  Clock,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { IActivityItem } from '@/types/dashboard';

interface RecentActivitySectionProps {
  activities: IActivityItem[];
}

const ACTIVITY_ICON_MAP = {
  create_project: FolderOpen,
  training_complete: CheckCircle2,
  model_deploy: Rocket,
  dataset_upload: Upload,
  member_join: UserPlus,
} as const;

const ACTIVITY_COLOR_MAP: Record<string, string> = {
  create_project: 'text-primary',
  training_complete: 'text-success',
  model_deploy: 'text-accent',
  dataset_upload: 'text-warning',
  member_join: 'text-chart-3',
};

function formatRelativeTime(iso: string): string {
  const now = Date.now();
  const diff = now - new Date(iso).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes} 分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} 小时前`;
  const days = Math.floor(hours / 24);
  return `${days} 天前`;
}

export default memo(function RecentActivitySection({ activities }: RecentActivitySectionProps) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <Clock className="size-4 text-muted-foreground" />
          最近活动
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-0">
        <div className="relative">
          {/* 时间线竖线 */}
          <div className="absolute left-[19px] top-1 bottom-1 w-px bg-border" />

          <div className="space-y-1">
            {activities.map((item, i) => {
              const Icon = ACTIVITY_ICON_MAP[item.type] ?? FolderOpen;
              const iconColor = ACTIVITY_COLOR_MAP[item.type] ?? 'text-muted-foreground';

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -8 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.04, ease: [0.16, 1, 0.3, 1] }}
                  className="relative flex items-start gap-3 py-2.5 pl-10 pr-3 rounded-lg hover:bg-muted/40 transition-colors"
                >
                  {/* 时间线节点 */}
                  <div className="absolute left-[15px] top-3.5 z-10 flex size-[9px] items-center justify-center rounded-full border-2 border-background bg-card ring-1 ring-border">
                    <div className={`size-[5px] rounded-full ${iconColor} bg-current`} />
                  </div>

                  {/* 图标 */}
                  <div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted/60">
                    <Icon className={`size-4 ${iconColor}`} />
                  </div>

                  {/* 内容 */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium truncate">{item.title}</span>
                      <span className="shrink-0 text-[11px] text-muted-foreground tabular-nums">
                        {formatRelativeTime(item.timestamp)}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">
                      {item.description}
                    </p>
                    {item.projectName && (
                      <Badge variant="outline" className="mt-1.5 text-[10px] h-5 px-1.5">
                        {item.projectName}
                      </Badge>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
});
