import { memo } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, FolderOpen, Cpu, Server, Activity } from 'lucide-react';

import { Card, CardContent } from '@/components/ui/card';
import type { IKpiCard } from '@/types/dashboard';

interface KpiCardsSectionProps {
  cards: IKpiCard[];
}

const ICON_MAP: Record<IKpiCard['icon'], React.ComponentType<{ className?: string }>> = {
  project: FolderOpen,
  training: Activity,
  deploy: Server,
  gpu: Cpu,
};

function KpiCardsSection({ cards }: KpiCardsSectionProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {cards.map((card, i) => {
        const Icon = ICON_MAP[card.icon];
        const isPositive = card.change >= 0;

        return (
          <motion.div
            key={card.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
          >
            <Card className="border-border/40 bg-card/60 backdrop-blur-sm hover:border-primary/30 transition-colors duration-300">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="space-y-1.5 min-w-0">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      {card.title}
                    </p>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-3xl font-bold tabular-nums tracking-tight text-foreground">
                        {card.value}
                      </span>
                      <span className="text-sm text-muted-foreground">{card.unit}</span>
                    </div>
                  </div>
                  <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="size-5 text-primary" />
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-1.5">
                  {isPositive ? (
                    <TrendingUp className="size-3.5 text-success" />
                  ) : (
                    <TrendingDown className="size-3.5 text-destructive" />
                  )}
                  <span
                    className={`text-xs font-semibold tabular-nums ${
                      isPositive ? 'text-success' : 'text-destructive'
                    }`}
                  >
                    {isPositive ? '+' : ''}
                    {card.change}%
                  </span>
                  <span className="text-xs text-muted-foreground">{card.changeLabel}</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}

export default memo(KpiCardsSection);
