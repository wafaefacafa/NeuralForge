import { memo } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Plus, Upload, Play, Rocket } from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

import KpiCardsSection from './KpiCardsSection';
import TrainingTrendChart from './TrainingTrendChart';
import ResourceUsageSection from './ResourceUsageSection';
import RecentActivitySection from './RecentActivitySection';
import QuickActionsSection from './QuickActionsSection';

import { MOCK_KPI_CARDS, MOCK_TRAINING_TREND, MOCK_RESOURCE_USAGE, MOCK_RECENT_ACTIVITIES } from '@/data/dashboard';

export default memo(function DashboardPage() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">控制台</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            欢迎回来，James Bond — 以下是您的平台概览
          </p>
        </div>
        <div className="hidden sm:flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            onClick={() => navigate('/projects/new')}
          >
            <Plus className="size-4" />
            新建项目
          </Button>
          <Button
            size="sm"
            className="gap-1.5"
            onClick={() => navigate('/projects')}
          >
            <Play className="size-4" />
            开始训练
          </Button>
        </div>
      </motion.div>

      {/* KPI 指标卡片行 */}
      <KpiCardsSection cards={MOCK_KPI_CARDS} />

      {/* 快速操作入口 */}
      <QuickActionsSection />

      {/* 图表区域：训练趋势 + 资源使用率 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 训练趋势图 - 占 2/3 */}
        <Card className="lg:col-span-2 border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">训练任务趋势</CardTitle>
            <p className="text-xs text-muted-foreground">近 7 天训练任务提交与完成统计</p>
          </CardHeader>
          <CardContent>
            <TrainingTrendChart data={MOCK_TRAINING_TREND} />
          </CardContent>
        </Card>

        {/* 资源使用率 - 占 1/3 */}
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">资源使用率</CardTitle>
            <p className="text-xs text-muted-foreground">当前集群资源占用情况</p>
          </CardHeader>
          <CardContent>
            <ResourceUsageSection data={MOCK_RESOURCE_USAGE} />
          </CardContent>
        </Card>
      </div>

      {/* 最近活动时间线 */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">最近活动</CardTitle>
          <p className="text-xs text-muted-foreground">平台最近 10 条操作记录</p>
        </CardHeader>
        <CardContent>
          <RecentActivitySection activities={MOCK_RECENT_ACTIVITIES} />
        </CardContent>
      </Card>
    </div>
  );
});
