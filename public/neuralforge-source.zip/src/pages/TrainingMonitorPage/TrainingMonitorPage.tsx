import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import {
  ArrowLeft,
  Play,
  Pause,
  Square,
  RefreshCw,
  Clock,
  Zap,
  Cpu,
  Activity,
  BarChart3,
  Terminal,
  AlertTriangle,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

import TrainingCurveChart from './TrainingCurveChart';
import GpuUtilizationGauge from './GpuUtilizationGauge';
import TrainingLogStream from './TrainingLogStream';
import EpochProgressBar from './EpochProgressBar';

import { MOCK_TRAINING_METRICS } from '@/data/trainingMetrics';
import { MOCK_TRAINING_LOGS } from '@/data/trainingLogs';
import type { ITrainingMetrics, ITrainingEpochMetrics, ITrainingLog } from '@/types/training';

// 模拟实时数据生成
function generateRealtimeMetrics(prev: ITrainingEpochMetrics): ITrainingEpochMetrics {
  const stepIncrement = Math.floor(Math.random() * 15) + 5;
  const newStep = Math.min(prev.step + stepIncrement, prev.totalSteps);
  const progress = newStep / prev.totalSteps;

  // Loss 震荡下降
  const trainLossDelta = (Math.random() - 0.55) * 0.04;
  const valLossDelta = (Math.random() - 0.52) * 0.05;
  const newTrainLoss = Math.max(0.01, +(prev.trainLoss + trainLossDelta).toFixed(4));
  const newValLoss = Math.max(0.01, +(prev.valLoss + valLossDelta).toFixed(4));

  // Accuracy 震荡上升
  const trainAccDelta = (Math.random() - 0.45) * 0.008;
  const valAccDelta = (Math.random() - 0.48) * 0.01;
  const newTrainAcc = Math.min(0.999, +(prev.trainAccuracy + trainAccDelta).toFixed(4));
  const newValAcc = Math.min(0.999, +(prev.valAccuracy + valAccDelta).toFixed(4));

  // GPU 利用率波动
  const gpuDelta = (Math.random() - 0.5) * 6;
  const newGpuUtil = Math.min(100, Math.max(40, +(prev.gpuUtilization + gpuDelta).toFixed(1)));

  // 学习率微调
  const lrDelta = (Math.random() - 0.5) * 0.00002;
  const newLr = Math.max(0.00001, +(prev.learningRate + lrDelta).toFixed(6));

  return {
    ...prev,
    step: newStep,
    trainLoss: newTrainLoss,
    valLoss: newValLoss,
    trainAccuracy: newTrainAcc,
    valAccuracy: newValAcc,
    gpuUtilization: newGpuUtil,
    learningRate: newLr,
    elapsedTime: prev.elapsedTime + 3,
    estimatedRemaining: Math.max(0, prev.estimatedRemaining - 3),
  };
}

function generateRealtimeLog(epoch: number, step: number, trainLoss: number, valLoss: number): ITrainingLog {
  const messages = [
    `Epoch ${epoch} Step ${step}: loss=${trainLoss.toFixed(4)}, val_loss=${valLoss.toFixed(4)}`,
    `Learning rate adjusted to ${(0.001 * Math.pow(0.97, epoch)).toFixed(6)}`,
    `Checkpoint saved: model_epoch_${epoch}_step_${step}.pt`,
    `Gradient norm: ${(Math.random() * 2 + 0.5).toFixed(3)}`,
    `Data loader prefetching batch ${step + 1}...`,
    `Validation metrics computed in ${(Math.random() * 3 + 1).toFixed(1)}s`,
  ];
  const msg = messages[Math.floor(Math.random() * messages.length)];

  return {
    id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    level: Math.random() > 0.95 ? 'warn' : 'info',
    message: msg,
    epoch,
    step,
  };
}

export default function TrainingMonitorPage() {
  const { jobId } = useParams<{ jobId: string }>();
  const navigate = useNavigate();

  // 从 mock 数据初始化
  const [metrics, setMetrics] = useState<ITrainingMetrics>(() => {
    const found = MOCK_TRAINING_METRICS.find((m) => m.jobId === jobId) ?? MOCK_TRAINING_METRICS[0];
    return { ...found, status: 'running' };
  });

  const [logs, setLogs] = useState<ITrainingLog[]>(() => {
    return MOCK_TRAINING_LOGS.filter((l) => l.id.startsWith('log_')).slice(0, 15);
  });

  const [status, setStatus] = useState<'running' | 'paused' | 'stopped'>('running');
  const [stopDialogOpen, setStopDialogOpen] = useState(false);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const logIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const logContainerRef = useRef<HTMLDivElement>(null);

  // 实时数据更新
  useEffect(() => {
    if (status !== 'running') return;

    intervalRef.current = setInterval(() => {
      setMetrics((prev) => {
        const currentMetrics = prev.epochMetrics[prev.epochMetrics.length - 1];
        if (!currentMetrics) return prev;

        const updated = generateRealtimeMetrics(currentMetrics);

        // 检查当前 epoch 是否完成
        if (updated.step >= updated.totalSteps) {
          // 进入下一个 epoch
          const nextEpoch = prev.currentEpoch + 1;
          if (nextEpoch > prev.totalEpochs) {
            // 训练完成
            toast.success('🎉 训练任务已完成！');
            logger.info('Training completed:', prev.jobId);
            return { ...prev, currentEpoch: prev.totalEpochs, status: 'completed' as const };
          }

          // 新 epoch 初始指标
          const newEpochMetrics: ITrainingEpochMetrics = {
            epoch: nextEpoch,
            trainLoss: +(updated.trainLoss * 0.95).toFixed(4),
            valLoss: +(updated.valLoss * 0.96).toFixed(4),
            trainAccuracy: Math.min(0.999, +(updated.trainAccuracy * 1.01).toFixed(4)),
            valAccuracy: Math.min(0.999, +(updated.valAccuracy * 1.008).toFixed(4)),
            learningRate: updated.learningRate,
            gpuUtilization: updated.gpuUtilization,
            gpuMemoryUsed: updated.gpuMemoryUsed,
            gpuMemoryTotal: updated.gpuMemoryTotal,
            step: 0,
            totalSteps: updated.totalSteps,
            elapsedTime: updated.elapsedTime,
            estimatedRemaining: updated.estimatedRemaining,
          };

          return {
            ...prev,
            currentEpoch: nextEpoch,
            epochMetrics: [...prev.epochMetrics, newEpochMetrics],
            bestValLoss: Math.min(prev.bestValLoss, newEpochMetrics.valLoss),
            bestValAccuracy: Math.max(prev.bestValAccuracy, newEpochMetrics.valAccuracy),
            updatedAt: new Date().toISOString(),
          };
        }

        // 更新当前 epoch 指标
        const updatedMetrics = [...prev.epochMetrics];
        updatedMetrics[updatedMetrics.length - 1] = updated;

        return {
          ...prev,
          epochMetrics: updatedMetrics,
          bestValLoss: Math.min(prev.bestValLoss, updated.valLoss),
          bestValAccuracy: Math.max(prev.bestValAccuracy, updated.valAccuracy),
          updatedAt: new Date().toISOString(),
        };
      });
    }, 3000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [status]);

  // 日志实时追加
  useEffect(() => {
    if (status !== 'running') return;

    logIntervalRef.current = setInterval(() => {
      setLogs((prev) => {
        const currentMetrics = metrics.epochMetrics[metrics.epochMetrics.length - 1];
        if (!currentMetrics) return prev;

        const newLog = generateRealtimeLog(
          metrics.currentEpoch,
          currentMetrics.step,
          currentMetrics.trainLoss,
          currentMetrics.valLoss,
        );
        return [...prev.slice(-200), newLog];
      });
    }, 5000);

    return () => {
      if (logIntervalRef.current) clearInterval(logIntervalRef.current);
    };
  }, [status, metrics.currentEpoch, metrics.epochMetrics]);

  // 日志自动滚动
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  // 暂停训练
  const handlePause = useCallback(() => {
    setStatus('paused');
    toast.info('训练已暂停');
    logger.info('Training paused:', jobId);
  }, [jobId]);

  // 恢复训练
  const handleResume = useCallback(() => {
    setStatus('running');
    toast.success('训练已恢复');
    logger.info('Training resumed:', jobId);
  }, [jobId]);

  // 停止训练
  const handleStop = useCallback(() => {
    setStopDialogOpen(true);
  }, []);

  const confirmStop = useCallback(() => {
    setStatus('stopped');
    setStopDialogOpen(false);
    toast.warning('训练已停止');
    logger.info('Training stopped:', jobId);
  }, [jobId]);

  // 返回
  const handleBack = useCallback(() => {
    navigate(-1);
  }, [navigate]);

  const currentEpochMetrics = metrics.epochMetrics[metrics.epochMetrics.length - 1];
  const epochProgress = metrics.totalEpochs > 0
    ? (metrics.currentEpoch / metrics.totalEpochs) * 100
    : 0;

  const stepProgress = currentEpochMetrics
    ? (currentEpochMetrics.step / currentEpochMetrics.totalSteps) * 100
    : 0;

  // 格式化时间
  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  };

  const statusBadge = {
    running: { label: '运行中', variant: 'default' as const, className: 'bg-success/15 text-success border-success/30' },
    paused: { label: '已暂停', variant: 'secondary' as const, className: 'bg-warning/15 text-warning border-warning/30' },
    stopped: { label: '已停止', variant: 'outline' as const, className: 'bg-muted text-muted-foreground' },
    completed: { label: '已完成', variant: 'default' as const, className: 'bg-success/15 text-success border-success/30' },
    failed: { label: '失败', variant: 'destructive' as const, className: '' },
  }[metrics.status] ?? statusBadge.running;

  return (
    <div className="space-y-6">
      {/* 顶部操作栏 */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"
      >
        {/* 左侧：返回 + 标题 */}
        <div className="flex items-center gap-3 min-w-0">
          <Button
            variant="ghost"
            size="icon"
            className="size-9 shrink-0"
            onClick={handleBack}
            aria-label="返回"
          >
            <ArrowLeft className="size-4" />
          </Button>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-semibold text-foreground truncate">
                {metrics.config.projectName}
              </h1>
              <Badge
                variant={statusBadge.variant}
                className={`shrink-0 text-xs ${statusBadge.className}`}
              >
                {statusBadge.label}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-0.5 truncate">
              任务 ID: {metrics.jobId} · {metrics.config.networkTemplate.name} · {metrics.config.hyperParams.optimizer.toUpperCase()}
            </p>
          </div>
        </div>

        {/* 右侧：控制按钮 */}
        <div className="flex items-center gap-2 shrink-0">
          {status === 'running' && (
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={handlePause}
            >
              <Pause className="size-3.5" />
              暂停
            </Button>
          )}
          {status === 'paused' && (
            <Button
              size="sm"
              className="gap-1.5"
              onClick={handleResume}
            >
              <Play className="size-3.5" />
              恢复
            </Button>
          )}
          {(status === 'running' || status === 'paused') && (
            <Button
              variant="destructive"
              size="sm"
              className="gap-1.5"
              onClick={handleStop}
            >
              <Square className="size-3.5" />
              停止
            </Button>
          )}
          {status === 'stopped' && (
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={() => toast.info('任务已停止，无法恢复')}
              disabled
            >
              <RefreshCw className="size-3.5" />
              已停止
            </Button>
          )}
        </div>
      </motion.div>

      {/* 实时指标卡片行 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
        className="grid grid-cols-2 md:grid-cols-4 gap-3"
      >
        {/* Train Loss */}
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Train Loss
              </span>
              <Activity className="size-3.5 text-primary" />
            </div>
            <p className="text-2xl font-bold tabular-nums tracking-tight text-foreground">
              {currentEpochMetrics?.trainLoss.toFixed(4) ?? '-'}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              最佳: {metrics.bestValLoss.toFixed(4)}
            </p>
          </CardContent>
        </Card>

        {/* Val Accuracy */}
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Val Accuracy
              </span>
              <BarChart3 className="size-3.5 text-accent" />
            </div>
            <p className="text-2xl font-bold tabular-nums tracking-tight text-foreground">
              {(currentEpochMetrics?.valAccuracy ?? 0) > 0
                ? `${(currentEpochMetrics!.valAccuracy * 100).toFixed(2)}%`
                : '-'}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              最佳: {(metrics.bestValAccuracy * 100).toFixed(2)}%
            </p>
          </CardContent>
        </Card>

        {/* GPU 利用率 */}
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                GPU 利用率
              </span>
              <Cpu className="size-3.5 text-chart-3" />
            </div>
            <p className="text-2xl font-bold tabular-nums tracking-tight text-foreground">
              {currentEpochMetrics?.gpuUtilization.toFixed(1) ?? '-'}%
            </p>
            <div className="mt-1.5">
              <Progress
                value={currentEpochMetrics?.gpuUtilization ?? 0}
                className="h-1.5"
              />
            </div>
          </CardContent>
        </Card>

        {/* 学习率 */}
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                学习率
              </span>
              <Zap className="size-3.5 text-warning" />
            </div>
            <p className="text-2xl font-bold tabular-nums tracking-tight text-foreground font-mono">
              {currentEpochMetrics?.learningRate.toExponential(4) ?? '-'}
            </p>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              调度器: {metrics.config.hyperParams.learningRateScheduler}
            </p>
          </CardContent>
        </Card>
      </motion.div>

      {/* Epoch 进度 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
      >
        <EpochProgressBar
          currentEpoch={metrics.currentEpoch}
          totalEpochs={metrics.totalEpochs}
          currentStep={currentEpochMetrics?.step ?? 0}
          totalSteps={currentEpochMetrics?.totalSteps ?? 0}
          elapsedTime={currentEpochMetrics?.elapsedTime ?? 0}
          estimatedRemaining={currentEpochMetrics?.estimatedRemaining ?? 0}
          status={status}
        />
      </motion.div>

      {/* 训练曲线 + GPU 仪表盘 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
        className="grid grid-cols-1 lg:grid-cols-3 gap-6"
      >
        {/* 训练曲线 - 占 2/3 */}
        <Card className="lg:col-span-2 border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="size-4 text-primary" />
              训练曲线
            </CardTitle>
          </CardHeader>
          <CardContent>
            <TrainingCurveChart metrics={metrics.epochMetrics} />
          </CardContent>
        </Card>

        {/* GPU 仪表盘 - 占 1/3 */}
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Cpu className="size-4 text-chart-3" />
              GPU 资源
            </CardTitle>
          </CardHeader>
          <CardContent>
            <GpuUtilizationGauge
              gpuUtilization={currentEpochMetrics?.gpuUtilization ?? 0}
              gpuMemoryUsed={currentEpochMetrics?.gpuMemoryUsed ?? 0}
              gpuMemoryTotal={currentEpochMetrics?.gpuMemoryTotal ?? 0}
              gpuType={metrics.config.gpuType}
              gpuCount={metrics.config.gpuCount}
            />
          </CardContent>
        </Card>
      </motion.div>

      {/* 训练日志 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
      >
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <Terminal className="size-4 text-primary" />
                训练日志
              </CardTitle>
              <Badge variant="outline" className="text-xs font-mono">
                {logs.length} 条
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <TrainingLogStream logs={logs} />
          </CardContent>
        </Card>
      </motion.div>

      {/* 停止确认对话框 */}
      <AlertDialog open={stopDialogOpen} onOpenChange={setStopDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="size-5 text-destructive" />
              停止训练
            </AlertDialogTitle>
            <AlertDialogDescription>
              确定要停止当前训练任务吗？已训练的模型权重和日志将被保留，但未完成的 Epoch 进度将丢失。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmStop}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              确认停止
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
