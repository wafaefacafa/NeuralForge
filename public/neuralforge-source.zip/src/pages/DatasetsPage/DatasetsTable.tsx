import { useState, useMemo } from 'react';
import { Search, Filter, Eye, Database, ChevronUp, ChevronDown, MoreHorizontal, Upload, Tag } from 'lucide-react';
import { toast } from 'sonner';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

import { MOCK_DATASETS } from '@/data/datasets';
import type { IDataset, IDatasetSample } from '@/types/datasets';

// 数据集状态映射
const STATUS_MAP: Record<IDataset['status'], { label: string; variant: 'default' | 'secondary' | 'destructive' }> = {
  ready: { label: '就绪', variant: 'default' },
  processing: { label: '处理中', variant: 'secondary' },
  error: { label: '异常', variant: 'destructive' },
};

// 格式映射
const FORMAT_MAP: Record<IDataset['format'], string> = {
  csv: 'CSV',
  json: 'JSON',
  parquet: 'Parquet',
  image: 'Image',
};

// 分类映射
const CATEGORY_MAP: Record<IDataset['category'], string> = {
  image: '图像',
  text: '文本',
  tabular: '表格',
  audio: '音频',
};

// 模拟数据预览样本
function generateMockSamples(dataset: IDataset): IDatasetSample[] {
  const samples: IDatasetSample[] = [];
  const count = Math.min(dataset.sampleCount, 20);

  if (dataset.category === 'image') {
    for (let i = 0; i < count; i++) {
      samples.push({
        id: `${dataset.id}-s-${i}`,
        datasetId: dataset.id,
        fields: {
          id: `${i + 1}`,
          file_name: `image_${String(i + 1).padStart(4, '0')}.jpg`,
          width: `${Math.floor(Math.random() * 800 + 200)}`,
          height: `${Math.floor(Math.random() * 600 + 200)}`,
          label: ['cat', 'dog', 'car', 'person', 'bird'][i % 5],
          format: 'JPEG',
        },
      });
    }
  } else if (dataset.category === 'text') {
    for (let i = 0; i < count; i++) {
      samples.push({
        id: `${dataset.id}-s-${i}`,
        datasetId: dataset.id,
        fields: {
          id: `${i + 1}`,
          text: `这是第 ${i + 1} 条文本样本数据，用于自然语言处理任务训练。`,
          label: ['positive', 'negative', 'neutral'][i % 3],
          length: `${Math.floor(Math.random() * 200 + 20)}`,
          source: ['web', 'book', 'social'][i % 3],
        },
      });
    }
  } else {
    for (let i = 0; i < count; i++) {
      samples.push({
        id: `${dataset.id}-s-${i}`,
        datasetId: dataset.id,
        fields: {
          id: `${i + 1}`,
          feature_1: `${(Math.random() * 100).toFixed(2)}`,
          feature_2: `${(Math.random() * 50).toFixed(2)}`,
          feature_3: `${(Math.random() * 200).toFixed(2)}`,
          label: ['A', 'B', 'C'][i % 3],
          category: ['train', 'val', 'test'][i % 3],
        },
      });
    }
  }
  return samples;
}

// 上传表单
function UploadDialog({ onUpload }: { onUpload: (name: string, desc: string, category: IDataset['category'], format: IDataset['format']) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IDataset['category']>('tabular');
  const [format, setFormat] = useState<IDataset['format']>('csv');
  const [open, setOpen] = useState(false);

  const handleSubmit = () => {
    if (!name.trim()) {
      toast.error('请输入数据集名称');
      return;
    }
    onUpload(name.trim(), description.trim(), category, format);
    toast.success(`数据集「${name}」上传成功`);
    setName('');
    setDescription('');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Upload className="mr-2 size-4" />
          上传数据集
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>上传数据集</DialogTitle>
          <DialogDescription>填写数据集基本信息，上传数据文件</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="ds-name">数据集名称</Label>
            <Input
              id="ds-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="例如：ImageNet-subset"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="ds-desc">描述</Label>
            <Textarea
              id="ds-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="数据集描述信息..."
              rows={2}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>数据分类</Label>
              <Select value={category} onValueChange={(v) => setCategory(v as IDataset['category'])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="image">图像</SelectItem>
                  <SelectItem value="text">文本</SelectItem>
                  <SelectItem value="tabular">表格</SelectItem>
                  <SelectItem value="audio">音频</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>文件格式</Label>
              <Select value={format} onValueChange={(v) => setFormat(v as IDataset['format'])}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="csv">CSV</SelectItem>
                  <SelectItem value="json">JSON</SelectItem>
                  <SelectItem value="parquet">Parquet</SelectItem>
                  <SelectItem value="image">Image</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="rounded-lg border border-dashed border-border p-8 text-center">
            <Upload className="mx-auto mb-2 size-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">拖拽文件到此处，或点击选择文件</p>
            <Button variant="outline" size="sm" className="mt-3" type="button">
              选择文件
            </Button>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>取消</Button>
          <Button onClick={handleSubmit}>确认上传</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// 数据预览抽屉
function PreviewSheet({ dataset }: { dataset: IDataset }) {
  const samples = useMemo(() => generateMockSamples(dataset), [dataset]);
  const fields = samples.length > 0 ? Object.keys(samples[0].fields) : [];

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm">
          <Eye className="mr-1.5 size-3.5" />
          预览
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:max-w-[720px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Database className="size-5 text-primary" />
            {dataset.name}
          </SheetTitle>
          <SheetDescription>
            数据预览 · 共 {dataset.sampleCount.toLocaleString()} 条样本 · 显示前 {samples.length} 条
          </SheetDescription>
        </SheetHeader>
        <div className="mt-6">
          <div className="w-full overflow-x-auto rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  {fields.map((field) => (
                    <TableHead key={field} className="whitespace-nowrap text-xs font-semibold">
                      {field}
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {samples.map((sample) => (
                  <TableRow key={sample.id}>
                    {fields.map((field) => (
                      <TableCell key={field} className="whitespace-nowrap text-xs">
                        <span className="block truncate max-w-[160px]">{sample.fields[field]}</span>
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// 版本历史抽屉
function VersionSheet({ dataset }: { dataset: IDataset }) {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm" className="text-muted-foreground">
          v{dataset.version}
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:max-w-[480px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle>版本历史</SheetTitle>
          <SheetDescription>{dataset.name} · 共 {dataset.versions.length} 个版本</SheetDescription>
        </SheetHeader>
        <div className="mt-6 space-y-3">
          {dataset.versions.map((v) => (
            <div
              key={v.id}
              className={`rounded-lg border p-4 ${v.version === dataset.version ? 'border-primary/40 bg-primary/5' : 'border-border'}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">v{v.version}</span>
                {v.version === dataset.version && (
                  <Badge variant="default" className="text-[10px]">当前</Badge>
                )}
              </div>
              <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                <span>{v.sampleCount.toLocaleString()} 样本</span>
                <span>{v.size}</span>
                <span>{v.createdAt}</span>
              </div>
              {v.changelog && (
                <p className="mt-2 text-xs text-muted-foreground">{v.changelog}</p>
              )}
            </div>
          ))}
        </div>
      </SheetContent>
    </Sheet>
  );
}

type SortField = 'name' | 'sampleCount' | 'size' | 'updatedAt';
type SortDir = 'asc' | 'desc';

export default function DatasetsTable() {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('updatedAt');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [datasets, setDatasets] = useState<IDataset[]>(MOCK_DATASETS);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDir('desc');
    }
  };

  const handleUpload = (name: string, desc: string, category: IDataset['category'], format: IDataset['format']) => {
    const newDataset: IDataset = {
      id: String(Date.now()),
      name,
      description: desc,
      sampleCount: 0,
      size: '0 B',
      version: '1.0',
      status: 'processing',
      format,
      category,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      versions: [
        {
          id: `${Date.now()}-v1`,
          version: '1.0',
          sampleCount: 0,
          size: '0 B',
          createdAt: new Date().toISOString().split('T')[0],
          changelog: '初始版本',
        },
      ],
    };
    setDatasets((prev) => [newDataset, ...prev]);
  };

  const filtered = useMemo(() => {
    let result = [...datasets];

    if (search.trim()) {
      const kw = search.trim().toLowerCase();
      result = result.filter(
        (d) =>
          d.name.toLowerCase().includes(kw) ||
          d.description.toLowerCase().includes(kw),
      );
    }

    if (categoryFilter !== 'all') {
      result = result.filter((d) => d.category === categoryFilter);
    }

    if (statusFilter !== 'all') {
      result = result.filter((d) => d.status === statusFilter);
    }

    result.sort((a, b) => {
      let cmp = 0;
      if (sortField === 'name') {
        cmp = a.name.localeCompare(b.name);
      } else if (sortField === 'sampleCount') {
        cmp = a.sampleCount - b.sampleCount;
      } else if (sortField === 'size') {
        cmp = a.size.localeCompare(b.size);
      } else if (sortField === 'updatedAt') {
        cmp = a.updatedAt.localeCompare(b.updatedAt);
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });

    return result;
  }, [datasets, search, categoryFilter, statusFilter, sortField, sortDir]);

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return sortDir === 'asc' ? (
      <ChevronUp className="ml-1 inline size-3.5" />
    ) : (
      <ChevronDown className="ml-1 inline size-3.5" />
    );
  };

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <CardTitle className="text-lg">数据集列表</CardTitle>
          <div className="flex flex-wrap items-center gap-2">
            {/* 搜索 */}
            <div className="relative w-full sm:w-56">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="搜索数据集..."
                className="h-9 bg-muted/50 pl-9 text-sm"
              />
            </div>

            {/* 分类筛选 */}
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="h-9 w-[110px]">
                <Filter className="mr-1.5 size-3.5 text-muted-foreground" />
                <SelectValue placeholder="分类" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部分类</SelectItem>
                <SelectItem value="image">图像</SelectItem>
                <SelectItem value="text">文本</SelectItem>
                <SelectItem value="tabular">表格</SelectItem>
                <SelectItem value="audio">音频</SelectItem>
              </SelectContent>
            </Select>

            {/* 状态筛选 */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="h-9 w-[110px]">
                <SelectValue placeholder="状态" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                <SelectItem value="ready">就绪</SelectItem>
                <SelectItem value="processing">处理中</SelectItem>
                <SelectItem value="error">异常</SelectItem>
              </SelectContent>
            </Select>

            {/* 上传按钮 */}
            <UploadDialog onUpload={handleUpload} />
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <div className="w-full overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead
                  className="whitespace-nowrap cursor-pointer select-none"
                  onClick={() => handleSort('name')}
                >
                  数据集名称 <SortIcon field="name" />
                </TableHead>
                <TableHead className="whitespace-nowrap">分类</TableHead>
                <TableHead className="whitespace-nowrap">格式</TableHead>
                <TableHead
                  className="whitespace-nowrap cursor-pointer select-none"
                  onClick={() => handleSort('sampleCount')}
                >
                  样本数 <SortIcon field="sampleCount" />
                </TableHead>
                <TableHead
                  className="whitespace-nowrap cursor-pointer select-none"
                  onClick={() => handleSort('size')}
                >
                  大小 <SortIcon field="size" />
                </TableHead>
                <TableHead className="whitespace-nowrap">版本</TableHead>
                <TableHead className="whitespace-nowrap">状态</TableHead>
                <TableHead
                  className="whitespace-nowrap cursor-pointer select-none"
                  onClick={() => handleSort('updatedAt')}
                >
                  更新时间 <SortIcon field="updatedAt" />
                </TableHead>
                <TableHead className="whitespace-nowrap text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="h-32 text-center">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Database className="size-8 opacity-40" />
                      <p className="text-sm">暂无匹配的数据集</p>
                      <p className="text-xs">尝试调整搜索条件或筛选器</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((dataset) => {
                  const statusInfo = STATUS_MAP[dataset.status];
                  return (
                    <TableRow key={dataset.id} className="group">
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2 min-w-0">
                          <Database className="size-4 shrink-0 text-muted-foreground" />
                          <div className="min-w-0">
                            <span className="block truncate max-w-[200px]">{dataset.name}</span>
                            <span className="block truncate max-w-[200px] text-xs text-muted-foreground">
                              {dataset.description}
                            </span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">
                          {CATEGORY_MAP[dataset.category]}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs text-muted-foreground font-mono">
                          {FORMAT_MAP[dataset.format]}
                        </span>
                      </TableCell>
                      <TableCell className="tabular-nums">
                        {dataset.sampleCount.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-muted-foreground">{dataset.size}</TableCell>
                      <TableCell>
                        <VersionSheet dataset={dataset} />
                      </TableCell>
                      <TableCell>
                        <Badge variant={statusInfo.variant} className="text-xs">
                          {statusInfo.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground text-sm">
                        {dataset.updatedAt}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <PreviewSheet dataset={dataset} />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toast.info(`数据标注: ${dataset.name}`)}
                          >
                            <Tag className="mr-1.5 size-3.5" />
                            标注
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="size-8">
                                <MoreHorizontal className="size-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                className="cursor-pointer"
                                onClick={() => toast.info(`下载: ${dataset.name}`)}
                              >
                                下载
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="cursor-pointer"
                                onClick={() => toast.info(`导出: ${dataset.name}`)}
                              >
                                导出
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="cursor-pointer text-destructive focus:text-destructive"
                                onClick={() => {
                                  setDatasets((prev) => prev.filter((d) => d.id !== dataset.id));
                                  toast.success(`已删除: ${dataset.name}`);
                                }}
                              >
                                删除
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
