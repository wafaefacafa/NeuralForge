import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

import { Button } from '@/components/ui/button';
import ProjectFormSection from './ProjectFormSection';
import type { ProjectFormConfig } from './ProjectFormSection';
import ConfigPreviewPanel from './ConfigPreviewPanel';

export default function CreateProjectPage() {
  const navigate = useNavigate();
  const [config, setConfig] = useState<ProjectFormConfig>({
    name: '',
    description: '',
    framework: '',
    gpuType: 'A100',
    gpuCount: 1,
    memoryGB: 64,
    tags: [],
  });

  const handleConfigChange = useCallback((c: ProjectFormConfig) => {
    setConfig(c);
  }, []);

  return (
    <div className="space-y-6">
      {/* 顶部返回栏 */}
      <motion.div
        initial={{ opacity: 0, x: -12 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="flex items-center gap-3"
      >
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/projects')}
          className="gap-1.5"
        >
          <ArrowLeft className="size-4" />
          返回项目列表
        </Button>
        <div className="flex-1">
          <h1 className="text-xl font-bold tracking-tight text-foreground">
            创建新项目
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            配置项目基本信息、深度学习框架和硬件资源
          </p>
        </div>
      </motion.div>

      {/* 左右分栏：配置表单 + 实时预览 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 左侧：配置表单（占 2/3） */}
        <div className="lg:col-span-2">
          <ProjectFormSection onConfigChange={handleConfigChange} />
        </div>

        {/* 右侧：实时预览面板（占 1/3） */}
        <div className="lg:col-span-1">
          <div className="sticky top-20">
            <ConfigPreviewPanel
              projectName={config.name}
              description={config.description}
              framework={config.framework || null}
              hardware={{ gpuType: config.gpuType as 'A100' | 'V100' | 'T4', gpuCount: config.gpuCount, memoryGB: config.memoryGB }}
              tags={config.tags}
              estimatedCost={0}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
