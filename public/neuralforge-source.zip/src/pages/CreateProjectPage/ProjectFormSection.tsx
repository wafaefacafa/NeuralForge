import { useState, useCallback, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import { Info, Cpu, HardDrive, Layers, Tag, Plus, X } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

import { PROJECT_FRAMEWORKS, GPU_OPTIONS, MEMORY_OPTIONS } from '@/data/projects';
import type { IProjectFramework } from '@/types/projects';

interface ProjectFormSectionProps {
  onConfigChange?: (config: ProjectFormConfig) => void;
}

export interface ProjectFormConfig {
  name: string;
  description: string;
  framework: IProjectFramework | '';
  gpuType: string;
  gpuCount: number;
  memoryGB: number;
  tags: string[];
}

const FRAMEWORK_DESCRIPTIONS: Record<IProjectFramework, string> = {
  PyTorch: '动态计算图，灵活易用，研究首选',
  TensorFlow: '生产级部署，TF Serving 生态成熟',
  JAX: '函数式编程，高性能计算，Google 前沿',
};

const GPU_PRICE_MAP: Record<string, number> = {
  A100: 3.06,
  V100: 2.48,
  T4: 0.95,
};

const MEMORY_PRICE_PER_GB = 0.005;

export default function ProjectFormSection({ onConfigChange }: ProjectFormSectionProps) {
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [framework, setFramework] = useState<IProjectFramework | ''>('');
  const [gpuType, setGpuType] = useState('A100');
  const [gpuCount, setGpuCount] = useState(1);
  const [memoryGB, setMemoryGB] = useState(64);
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const estimatedHourlyCost =
    (GPU_PRICE_MAP[gpuType] || 0) * gpuCount + memoryGB * MEMORY_PRICE_PER_GB;

  const emitConfig = useCallback(() => {
    onConfigChange?.({
      name,
      description,
      framework,
      gpuType,
      gpuCount,
      memoryGB,
      tags,
    });
  }, [name, description, framework, gpuType, gpuCount, memoryGB, tags, onConfigChange]);

  const handleAddTag = useCallback(() => {
    const trimmed = tagInput.trim();
    if (!trimmed) return;
    if (tags.includes(trimmed)) {
      toast.info('标签已存在');
      return;
    }
    if (tags.length >= 8) {
      toast.info('最多添加 8 个标签');
      return;
    }
    setTags((prev) => [...prev, trimmed]);
    setTagInput('');
  }, [tagInput, tags]);

  const handleRemoveTag = useCallback((tag: string) => {
    setTags((prev) => prev.filter((t) => t !== tag));
  }, []);

  const handleTagKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleAddTag();
      }
    },
    [handleAddTag],
  );

  const handleSubmit = useCallback(
    async (e: FormEvent) => {
      e.preventDefault();

      if (!name.trim()) {
        toast.error('请输入项目名称');
        return;
      }
      if (!framework) {
        toast.error('请选择深度学习框架');
        return;
      }

      setSubmitting(true);
      try {
        await new Promise((r) => setTimeout(r, 800));
        toast.success('项目创建成功！');
        logger.info('Project created:', { name, framework, gpuType, gpuCount, memoryGB });
        navigate('/projects');
      } catch (err) {
        logger.error('Create project failed:', String(err));
        toast.error('创建失败，请重试');
      } finally {
        setSubmitting(false);
      }
    },
    [name, framework, gpuType, gpuCount, memoryGB, navigate],
  );

  const selectedGpu = GPU_OPTIONS.find((g) => g.value === gpuType);

  return (
    <form onSubmit={handleSubmit} className="space-y-6" onChange={emitConfig}>
      {/* 基本信息 */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Info className="size-5 text-primary" />
            基本信息
          </CardTitle>
          <CardDescription>配置项目名称、描述和标签</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* 项目名称 */}
          <div className="space-y-2">
            <Label htmlFor="project-name" className="text-sm font-medium">
              项目名称 <span className="text-destructive">*</span>
            </Label>
            <Input
              id="project-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="例如：图像分类 ResNet-50"
              maxLength={50}
              className="bg-muted/50"
            />
            <p className="text-[11px] text-muted-foreground">
              {name.length}/50 字符
            </p>
          </div>

          {/* 项目描述 */}
          <div className="space-y-2">
            <Label htmlFor="project-desc" className="text-sm font-medium">
              项目描述
            </Label>
            <Textarea
              id="project-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="简要描述项目目标和应用场景..."
              rows={3}
              maxLength={200}
              className="bg-muted/50 resize-none"
            />
            <p className="text-[11px] text-muted-foreground">
              {description.length}/200 字符
            </p>
          </div>

          {/* 标签 */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">标签</Label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Tag className="pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={handleTagKeyDown}
                  placeholder="输入标签后按回车添加"
                  maxLength={20}
                  className="bg-muted/50 pl-9"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleAddTag}
                disabled={!tagInput.trim()}
              >
                <Plus className="size-3.5" />
                添加
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="gap-1 pr-1 cursor-default"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-0.5 rounded-full p-0.5 hover:bg-muted-foreground/20 transition-colors"
                      aria-label={`移除标签 ${tag}`}
                    >
                      <X className="size-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 框架选择 */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Layers className="size-5 text-primary" />
            深度学习框架 <span className="text-destructive">*</span>
          </CardTitle>
          <CardDescription>选择项目使用的深度学习框架</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {PROJECT_FRAMEWORKS.map((fw) => {
              const isSelected = framework === fw.value;
              return (
                <motion.button
                  key={fw.value}
                  type="button"
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => setFramework(fw.value)}
                  className={`relative flex flex-col items-center gap-2 rounded-xl border-2 p-5 text-left transition-all duration-200 ${
                    isSelected
                      ? 'border-primary bg-primary/10 shadow-sm shadow-primary/10'
                      : 'border-border/40 bg-muted/30 hover:border-primary/40 hover:bg-muted/50'
                  }`}
                >
                  <span className="text-2xl">{fw.icon}</span>
                  <span
                    className={`text-sm font-semibold ${
                      isSelected ? 'text-primary' : 'text-foreground'
                    }`}
                  >
                    {fw.label}
                  </span>
                  <span className="text-[11px] text-muted-foreground text-center leading-relaxed">
                    {FRAMEWORK_DESCRIPTIONS[fw.value]}
                  </span>
                  {isSelected && (
                    <div className="absolute -top-1.5 -right-1.5 flex size-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                      ✓
                    </div>
                  )}
                </motion.button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* 硬件资源配置 */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Cpu className="size-5 text-primary" />
            硬件资源配置
          </CardTitle>
          <CardDescription>选择 GPU 类型、数量和内存规格</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* GPU 类型 */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">GPU 类型</Label>
            <Select value={gpuType} onValueChange={setGpuType}>
              <SelectTrigger className="bg-muted/50">
                <SelectValue placeholder="选择 GPU 类型" />
              </SelectTrigger>
              <SelectContent>
                {GPU_OPTIONS.map((gpu) => (
                  <SelectItem key={gpu.value} value={gpu.value}>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{gpu.label}</span>
                      <span className="text-xs text-muted-foreground">
                        ${GPU_PRICE_MAP[gpu.value]}/h
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedGpu && (
              <p className="text-[11px] text-muted-foreground">
                {selectedGpu.vram} 显存 · {selectedGpu.cores} CUDA 核心
              </p>
            )}
          </div>

          {/* GPU 数量 */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">GPU 数量</Label>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="text-sm font-bold tabular-nums text-primary">
                      {gpuCount} 卡
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>建议根据模型规模选择 1-8 卡</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <Slider
              value={[gpuCount]}
              onValueChange={([v]) => setGpuCount(v)}
              min={1}
              max={8}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-[11px] text-muted-foreground">
              <span>1</span>
              <span>2</span>
              <span>4</span>
              <span>8</span>
            </div>
          </div>

          {/* 内存规格 */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">内存规格</Label>
            <Select
              value={String(memoryGB)}
              onValueChange={(v) => setMemoryGB(Number(v))}
            >
              <SelectTrigger className="bg-muted/50">
                <SelectValue placeholder="选择内存规格" />
              </SelectTrigger>
              <SelectContent>
                {MEMORY_OPTIONS.map((mem) => (
                  <SelectItem key={mem.value} value={String(mem.value)}>
                    {mem.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* 费用预估摘要 */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <HardDrive className="size-5 text-accent" />
            费用预估
          </CardTitle>
          <CardDescription>基于所选配置的每小时预估费用</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                GPU ({gpuType} × {gpuCount})
              </span>
              <span className="font-medium tabular-nums">
                ${(GPU_PRICE_MAP[gpuType] * gpuCount).toFixed(2)}/h
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">内存 ({memoryGB} GB)</span>
              <span className="font-medium tabular-nums">
                ${(memoryGB * MEMORY_PRICE_PER_GB).toFixed(2)}/h
              </span>
            </div>
            <div className="border-t border-border/40 pt-3 flex items-center justify-between">
              <span className="text-sm font-semibold">预估合计</span>
              <span className="text-lg font-bold tabular-nums text-accent">
                ${estimatedHourlyCost.toFixed(2)}
                <span className="text-xs font-normal text-muted-foreground">/小时</span>
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground">
              预估月费用约 ${(estimatedHourlyCost * 730).toFixed(0)}（按 730 小时/月计算），实际费用以账单为准
            </p>
          </div>
        </CardContent>
      </Card>

      {/* 提交按钮 */}
      <div className="flex items-center justify-end gap-3 pt-2">
        <Button
          type="button"
          variant="outline"
          onClick={() => navigate('/projects')}
        >
          取消
        </Button>
        <Button type="submit" disabled={submitting} size="lg">
          {submitting ? (
            <>
              <span className="mr-2 inline-block size-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
              创建中...
            </>
          ) : (
            '创建项目'
          )}
        </Button>
      </div>
    </form>
  );
}
