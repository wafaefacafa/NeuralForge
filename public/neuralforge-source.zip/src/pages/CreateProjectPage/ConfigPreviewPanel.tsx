import { memo } from 'react';
import { motion } from 'framer-motion';
import {
  Cpu,
  HardDrive,
  Layers,
  Tag,
  DollarSign,
  Sparkles,
} from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import type { IProjectFramework, IProjectHardwareConfig } from '@/types/projects';

interface ConfigPreviewPanelProps {
  projectName: string;
  description: string;
  framework: IProjectFramework | null;
  hardware: IProjectHardwareConfig;
  tags: string[];
  estimatedCost: number;
}

const FRAMEWORK_META: Record<IProjectFramework, { label: string; icon: string; color: string }> = {
  PyTorch: { label: 'PyTorch', icon: '🔥', color: 'bg-orange-500/10 text-orange-400 border-orange-500/20' },
  TensorFlow: { label: 'TensorFlow', icon: '🧠', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  JAX: { label: 'JAX', icon: '⚡', color: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
};

const GPU_PRICE_MAP: Record<string, number> = {
  A100: 3.06,
  V100: 2.48,
  T4: 0.95,
};

function ConfigPreviewPanel({
  projectName,
  description,
  framework,
  hardware,
  tags,
  estimatedCost,
}: ConfigPreviewPanelProps) {
  const gpuUnitPrice = GPU_PRICE_MAP[hardware.gpuType] ?? 0;
  const gpuCost = gpuUnitPrice * hardware.gpuCount;
  const memoryCost = (hardware.memoryGB / 32) * 0.15;
  const totalHourly = gpuCost + memoryCost;
  const totalMonthly = totalHourly * 730;

  const displayCost = estimatedCost > 0 ? estimatedCost : totalMonthly;

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className="space-y-4"
    >
      {/* 配置摘要卡片 */}
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Sparkles className="size-4 text-primary" />
            配置预览
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 项目名称 */}
          <div className="space-y-1">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              项目名称
            </span>
            <p className="text-sm font-semibold text-foreground">
              {projectName || '未命名项目'}
            </p>
          </div>

          {/* 描述 */}
          {description && (
            <div className="space-y-1">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                项目描述
              </span>
              <p className="line-clamp-3 text-sm text-muted-foreground">
                {description}
              </p>
            </div>
          )}

          <Separator className="bg-border/40" />

          {/* 框架选择 */}
          <div className="space-y-1.5">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              深度学习框架
            </span>
            {framework ? (
              <Badge
                variant="outline"
                className={`text-xs font-medium ${FRAMEWORK_META[framework].color}`}
              >
                {FRAMEWORK_META[framework].icon} {FRAMEWORK_META[framework].label}
              </Badge>
            ) : (
              <p className="text-sm text-muted-foreground italic">未选择</p>
            )}
          </div>

          <Separator className="bg-border/40" />

          {/* 硬件资源配置 */}
          <div className="space-y-3">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              硬件资源配置
            </span>

            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center gap-2 rounded-lg border border-border/40 bg-muted/30 px-3 py-2.5">
                <Cpu className="size-4 shrink-0 text-accent" />
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">GPU 型号</p>
                  <p className="text-sm font-semibold tabular-nums">
                    {hardware.gpuType}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 rounded-lg border border-border/40 bg-muted/30 px-3 py-2.5">
                <Layers className="size-4 shrink-0 text-primary" />
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">GPU 数量</p>
                  <p className="text-sm font-semibold tabular-nums">
                    {hardware.gpuCount} 卡
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 rounded-lg border border-border/40 bg-muted/30 px-3 py-2.5">
                <HardDrive className="size-4 shrink-0 text-chart-4" />
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">内存规格</p>
                  <p className="text-sm font-semibold tabular-nums">
                    {hardware.memoryGB} GB
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 rounded-lg border border-border/40 bg-muted/30 px-3 py-2.5">
                <DollarSign className="size-4 shrink-0 text-chart-3" />
                <div className="min-w-0">
                  <p className="text-[11px] text-muted-foreground">GPU 单价</p>
                  <p className="text-sm font-semibold tabular-nums">
                    ${gpuUnitPrice.toFixed(2)}/h
                  </p>
                </div>
              </div>
            </div>
          </div>

          <Separator className="bg-border/40" />

          {/* 标签 */}
          <div className="space-y-1.5">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              项目标签
            </span>
            {tags.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="text-[11px]"
                  >
                    <Tag className="mr-1 size-3" />
                    {tag}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground italic">未添加标签</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 费用预估卡片 */}
      <Card className="border-accent/20 bg-accent/5 backdrop-blur-sm">
        <CardContent className="p-5">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                预估月费用
              </p>
              <div className="flex items-baseline gap-1">
                <span className="text-2xl font-bold tabular-nums tracking-tight text-accent">
                  ${displayCost.toFixed(0)}
                </span>
                <span className="text-sm text-muted-foreground">/月</span>
              </div>
            </div>
            <div className="rounded-full bg-accent/10 p-2.5">
              <DollarSign className="size-5 text-accent" />
            </div>
          </div>

          <div className="mt-3 space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">
                GPU ({hardware.gpuType} × {hardware.gpuCount})
              </span>
              <span className="font-medium tabular-nums text-foreground">
                ${(gpuCost * 730).toFixed(0)}/月
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">
                内存 ({hardware.memoryGB} GB)
              </span>
              <span className="font-medium tabular-nums text-foreground">
                ${(memoryCost * 730).toFixed(0)}/月
              </span>
            </div>
            <Separator className="my-1.5 bg-border/30" />
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-foreground">合计（按 730h/月）</span>
              <span className="font-bold tabular-nums text-accent">
                ${displayCost.toFixed(0)}/月
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export default memo(ConfigPreviewPanel);
