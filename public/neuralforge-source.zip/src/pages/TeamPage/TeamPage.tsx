import { useState, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit-lite';
import { Users, UserPlus, Search, Filter } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

import { MOCK_TEAM_MEMBERS, MOCK_TEAM_STATS } from '@/data/teamMembers';
import type { ITeamMember, ITeamInviteForm } from '@/types/team';

import TeamStatsCards from './TeamStatsCards';
import TeamMembersTable from './TeamMembersTable';
import InviteMemberDialog from './InviteMemberDialog';
import EditMemberDialog from './EditMemberDialog';

export default function TeamPage() {
  const [members, setMembers] = useState<ITeamMember[]>(MOCK_TEAM_MEMBERS);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // 对话框状态
  const [inviteOpen, setInviteOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<ITeamMember | null>(null);
  const [editOpen, setEditOpen] = useState(false);

  // 筛选后的成员列表
  const filteredMembers = useMemo(() => {
    return members.filter((m) => {
      const matchSearch =
        !searchKeyword.trim() ||
        m.name.toLowerCase().includes(searchKeyword.toLowerCase()) ||
        m.email.toLowerCase().includes(searchKeyword.toLowerCase());
      const matchRole = roleFilter === 'all' || m.role === roleFilter;
      const matchStatus = statusFilter === 'all' || m.status === statusFilter;
      return matchSearch && matchRole && matchStatus;
    });
  }, [members, searchKeyword, roleFilter, statusFilter]);

  // 邀请成员
  const handleInvite = useCallback(
    async (form: ITeamInviteForm) => {
      try {
        await new Promise((r) => setTimeout(r, 800));

        const newMember: ITeamMember = {
          id: `member_${Date.now()}`,
          name: form.email.split('@')[0],
          email: form.email,
          role: form.role,
          status: 'pending',
          joinedAt: new Date().toISOString(),
          lastActiveAt: '-',
          permissions: {
            projectAccess: form.role !== 'viewer',
            datasetAccess: form.role !== 'viewer',
            deployAccess: form.role === 'admin',
          },
        };

        setMembers((prev) => [newMember, ...prev]);
        toast.success(`邀请已发送至 ${form.email}`);
        logger.info('Member invited:', form.email);
        setInviteOpen(false);
      } catch (err) {
        logger.error('Invite member failed:', String(err));
        toast.error('邀请失败，请重试');
      }
    },
    [],
  );

  // 编辑成员
  const handleEditMember = useCallback((member: ITeamMember) => {
    setEditTarget(member);
    setEditOpen(true);
  }, []);

  // 保存编辑
  const handleSaveEdit = useCallback((updated: ITeamMember) => {
    setMembers((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));
  }, []);

  // 移除成员
  const handleRemoveMember = useCallback((member: ITeamMember) => {
    setMembers((prev) => prev.filter((m) => m.id !== member.id));
    toast.success(`${member.name} 已被移出团队`);
    logger.info('Member removed:', member.email);
  }, []);

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">团队协作</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            管理团队成员、角色和访问权限
          </p>
        </div>
        <Button
          className="gap-1.5 mt-2 sm:mt-0"
          onClick={() => setInviteOpen(true)}
        >
          <UserPlus className="size-4" />
          邀请成员
        </Button>
      </motion.div>

      {/* 统计卡片 */}
      <TeamStatsCards stats={MOCK_TEAM_STATS} />

      {/* 搜索与筛选栏 */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.1 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center"
      >
        {/* 搜索框 */}
        <div className="relative flex-1 max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            placeholder="搜索成员姓名或邮箱..."
            className="bg-muted/50 pl-9"
          />
        </div>

        {/* 筛选器 */}
        <div className="flex items-center gap-2">
          <Filter className="size-4 text-muted-foreground shrink-0" />
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-[130px] h-9 bg-muted/50 text-sm">
              <SelectValue placeholder="角色" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部角色</SelectItem>
              <SelectItem value="admin">管理员</SelectItem>
              <SelectItem value="developer">开发者</SelectItem>
              <SelectItem value="viewer">观察者</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[120px] h-9 bg-muted/50 text-sm">
              <SelectValue placeholder="状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="active">活跃</SelectItem>
              <SelectItem value="inactive">未活跃</SelectItem>
              <SelectItem value="pending">待接受</SelectItem>
            </SelectContent>
          </Select>

          {/* 清除筛选 */}
          {(searchKeyword || roleFilter !== 'all' || statusFilter !== 'all') && (
            <Button
              variant="ghost"
              size="sm"
              className="h-9 text-xs text-muted-foreground"
              onClick={() => {
                setSearchKeyword('');
                setRoleFilter('all');
                setStatusFilter('all');
              }}
            >
              清除
            </Button>
          )}
        </div>
      </motion.div>

      {/* 成员列表 */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.15 }}
      >
        <TeamMembersTable
          members={filteredMembers}
          onEdit={handleEditMember}
          onRemove={handleRemoveMember}
        />
      </motion.div>

      {/* 邀请成员对话框 */}
      <InviteMemberDialog
        open={inviteOpen}
        onOpenChange={setInviteOpen}
        onInvite={handleInvite}
      />

      {/* 编辑成员对话框 */}
      <EditMemberDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        member={editTarget}
        onSave={handleSaveEdit}
      />
    </div>
  );
}
